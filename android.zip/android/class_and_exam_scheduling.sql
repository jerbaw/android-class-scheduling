-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 13, 2025 at 08:44 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `class_and_exam_scheduling`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--
CREATE TABLE IF NOT EXISTS `assignments` (
  `assignment_id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `section_id` int NOT NULL,
  `instructor_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `entry_year` int DEFAULT NULL,
  PRIMARY KEY (`assignment_id`),
  UNIQUE KEY `unique_assignment` (`course_id`,`section_id`,`entry_year`),
  KEY `section_id` (`section_id`),
  KEY `instructor_id` (`instructor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`assignment_id`, `course_id`, `section_id`, `instructor_id`, `created_at`, `entry_year`) VALUES
(54, 192, 3, 1, '2025-01-12 21:58:17', 2012),
(53, 192, 2, 1, '2025-01-12 21:58:08', 2012),
(52, 192, 1, 1, '2025-01-12 21:57:55', 2012);

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

DROP TABLE IF EXISTS `classrooms`;
CREATE TABLE IF NOT EXISTS `classrooms` (
  `classroom_id` int NOT NULL AUTO_INCREMENT,
  `room_name` varchar(50) NOT NULL,
  `capacity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`classroom_id`),
  UNIQUE KEY `room_name` (`room_name`)
)ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
--
-- Dumping data for table `classrooms`
--

INSERT INTO `classrooms` (`classroom_id`, `room_name`, `capacity`, `created_at`) VALUES
(1, 'Room A', 30, '2025-01-07 11:11:46'),
(2, 'Room B', 50, '2025-01-07 11:11:46'),
(3, 'Room C', 20, '2025-01-07 11:11:46'),
(4, 'Room F', 40, '2025-01-07 11:12:38');

-- --------------------------------------------------------

--
-- Table structure for table `class_schedule`
--

DROP TABLE IF EXISTS `class_schedule`;
CREATE TABLE IF NOT EXISTS `class_schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `section_id` int NOT NULL,
  `instructor_id` int NOT NULL,
  `classroom_id` int NOT NULL,
  `entry_year` int NOT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  KEY `course_id` (`course_id`),
  KEY `section_id` (`section_id`),
  KEY `instructor_id` (`instructor_id`),
  KEY `classroom_id` (`classroom_id`),
  KEY `entry_year` (`entry_year`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_schedule`
--

INSERT INTO `class_schedule` (`schedule_id`, `course_id`, `section_id`, `instructor_id`, `classroom_id`, `entry_year`, `day_of_week`, `start_time`, `end_time`, `created_at`) VALUES
(350, 196, 3, 1, 1, 2013, 'Thursday', '08:00:00', '11:00:00', '2025-01-12 06:00:11'),
(351, 195, 1, 3, 1, 2013, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(352, 193, 2, 3, 1, 2012, 'Friday', '09:00:00', '10:00:00', '2025-01-12 06:00:11'),
(353, 196, 2, 1, 1, 2013, 'Tuesday', '08:00:00', '11:00:00', '2025-01-12 06:00:11'),
(354, 196, 1, 1, 1, 2013, 'Wednesday', '08:00:00', '11:00:00', '2025-01-12 06:00:11'),
(355, 192, 2, 1, 1, 2012, 'Thursday', '11:00:00', '13:00:00', '2025-01-12 06:00:11'),
(356, 195, 2, 3, 2, 2013, 'Wednesday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(357, 192, 1, 1, 1, 2012, 'Wednesday', '11:00:00', '13:00:00', '2025-01-12 06:00:11'),
(358, 194, 3, 8, 1, 2012, 'Monday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(359, 194, 2, 8, 2, 2012, 'Thursday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(360, 194, 1, 8, 2, 2012, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(361, 193, 3, 3, 2, 2012, 'Wednesday', '09:00:00', '10:00:00', '2025-01-12 06:00:11'),
(362, 193, 1, 3, 2, 2012, 'Monday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(363, 192, 3, 1, 3, 2012, 'Monday', '08:00:00', '10:00:00', '2025-01-12 06:00:11'),
(364, 195, 3, 3, 1, 2013, 'Friday', '10:00:00', '11:00:00', '2025-01-12 06:00:11'),
(365, 194, 1, 1, 1, 2014, 'Wednesday', '13:00:00', '14:00:00', '2025-01-12 06:00:11'),
(366, 195, 2, 3, 2, 2014, 'Wednesday', '10:00:00', '11:00:00', '2025-01-12 06:00:11'),
(367, 195, 1, 3, 1, 2014, 'Friday', '11:00:00', '12:00:00', '2025-01-12 06:00:11'),
(368, 194, 2, 1, 3, 2014, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(369, 193, 1, 11, 3, 2014, 'Wednesday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(370, 193, 2, 11, 4, 2014, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(371, 192, 1, 13, 2, 2017, 'Friday', '09:00:00', '11:00:00', '2025-01-12 06:00:11'),
(372, 192, 1, 13, 4, 2016, 'Monday', '08:00:00', '10:00:00', '2025-01-12 06:00:11'),
(373, 192, 1, 13, 3, 2014, 'Thursday', '08:00:00', '10:00:00', '2025-01-12 06:00:11');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--
DROP TABLE IF EXISTS `complaints`;
CREATE TABLE IF NOT EXISTS `complaints` (
  `complaint_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `description` text NOT NULL,
  `status` enum('pending','resolved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`complaint_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`complaint_id`, `user_id`, `description`, `status`, `created_at`) VALUES
(1, 1, 'Class schedule not posted for next semester.', 'resolved', '2025-01-07 11:18:53'),
(2, 2, 'Exam date for Mathematics conflicts with another exam.', 'pending', '2025-01-07 11:18:53'),
(3, 3, 'Room change notification for Chemistry class was too late.', 'resolved', '2025-01-07 11:18:53'),
(4, 4, 'Inaccurate timing listed for Biology exam.', 'pending', '2025-01-07 11:18:53'),
(5, 2, 'Need more time between classes to transition between buildings.', 'pending', '2025-01-07 11:18:53'),
(6, 5, 'Confusion over the venue for the History exam.', 'resolved', '2025-01-07 11:18:53'),
(7, 1, 'Classroom not available for scheduled Computer Science class.', 'pending', '2025-01-07 11:18:53'),
(8, 3, 'Difficulty accessing online materials for upcoming exams.', 'pending', '2025-01-07 11:18:53'),
(9, 4, 'Last-minute changes to the Physics exam schedule.', 'rejected', '2025-01-07 11:18:53'),
(10, 6, 'Lack of communication regarding canceled classes.', 'pending', '2025-01-07 11:18:53'),
(11, 10, 'what happened to you registrar can you change the exam day for Thursday? ', 'rejected', '2025-01-09 16:57:24'),
(12, 11, 'hi i am instructor ', 'pending', '2025-01-09 17:13:02'),
(13, 3, 'test compliant', 'pending', '2025-01-09 17:14:39'),
(14, 10, 'Notifications test ', 'pending', '2025-01-09 17:38:59'),
(15, 10, 'Notifications test 2', 'pending', '2025-01-09 17:40:21'),
(16, 12, 'hi', 'pending', '2025-01-11 15:44:25'),
(17, 12, 'hi2', 'pending', '2025-01-11 15:45:09'),
(18, 12, 'habibity is my name', 'pending', '2025-01-11 16:01:29'),
(19, 12, 'ok good', 'pending', '2025-01-11 16:01:44'),
(20, 13, 'hihi', 'pending', '2025-01-12 07:50:53'),
(21, 14, 'complain', 'pending', '2025-01-12 08:22:42');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `course_id` int NOT NULL AUTO_INCREMENT,
  `course_name` varchar(100) NOT NULL,
  `department_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `duration` int DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  UNIQUE KEY `unique_course_name` (`course_name`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `department_id`, `created_at`, `duration`) VALUES
(192, 'Mathematics 101', 1, '2025-01-08 04:36:20', 2),
(193, 'Biology 101', 2, '2025-01-08 04:36:20', 1),
(194, 'History 101', 3, '2025-01-08 04:36:20', 1),
(195, 'Literature 101', 1, '2025-01-08 04:36:20', 1),
(196, 'Computer Science 101', 1, '2025-01-08 04:36:20', 3);

-- --------------------------------------------------------

--
-- Table structure for table `course_enrollment`
--

DROP TABLE IF EXISTS `course_enrollment`;
CREATE TABLE IF NOT EXISTS `course_enrollment` (
  `enrollment_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `course_id` int NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  KEY `student_id` (`student_id`),
  KEY `course_id` (`course_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_enrollment`
--

INSERT INTO `course_enrollment` (`enrollment_id`, `student_id`, `course_id`) VALUES
(1, 10, 192),
(2, 10, 195),
(4, 10, 196),
(5, 12, 192),
(6, 12, 192),
(7, 12, 192),
(8, 12, 195);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE IF NOT EXISTS `departments` (
  `department_id` int NOT NULL AUTO_INCREMENT,
  `department_name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `department_head` int DEFAULT NULL,
  PRIMARY KEY (`department_id`),
  UNIQUE KEY `department_name` (`department_name`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`, `created_at`, `department_head`) VALUES
(1, 'Computer Science', '2025-01-07 10:55:30', 4),
(2, 'Mathematics', '2025-01-07 10:52:24', 3),
(3, 'ICT', '2025-01-07 10:52:27', 4),
(4, 'Markrting', '2025-01-07 10:52:30', 3),
(9, 'Humanities', '2025-01-08 03:45:16', 4),
(8, 'Science', '2025-01-08 03:45:16', 3);

-- --------------------------------------------------------

--
-- Table structure for table `entry_year`
--

DROP TABLE IF EXISTS `entry_year`;
CREATE TABLE IF NOT EXISTS `entry_year` (
  `year_id` int NOT NULL AUTO_INCREMENT,
  `year` int NOT NULL,
  PRIMARY KEY (`year_id`),
  UNIQUE KEY `year` (`year`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `entry_year`
--

INSERT INTO `entry_year` (`year_id`, `year`) VALUES
(1, 2013),
(2, 2014),
(4, 2016),
(5, 2017),
(6, 2012);

-- --------------------------------------------------------

--
-- Table structure for table `entry_year_enrollment`
--

DROP TABLE IF EXISTS `entry_year_enrollment`;
CREATE TABLE IF NOT EXISTS `entry_year_enrollment` (
  `enrollment_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `year_id` int NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  KEY `student_id` (`student_id`),
  KEY `year_id` (`year_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `entry_year_enrollment`
--

INSERT INTO `entry_year_enrollment` (`enrollment_id`, `student_id`, `year_id`) VALUES
(5, 10, 2),
(6, 12, 2),
(7, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam_schedule`
--

DROP TABLE IF EXISTS `exam_schedule`;
CREATE TABLE IF NOT EXISTS `exam_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exam_date` date NOT NULL,
  `exam_time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `classroom_id` int NOT NULL,
  `course_id` int NOT NULL,
  `section_id` int NOT NULL,
  `year_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_schedule`
--

INSERT INTO `exam_schedule` (`id`, `exam_date`, `exam_time`, `created_at`, `classroom_id`, `course_id`, `section_id`, `year_id`) VALUES
(3, '2025-01-12', '21:43:00', '2025-01-12 13:43:41', 1, 194, 1, 1),
(4, '2025-01-13', '16:44:00', '2025-01-12 13:44:53', 2, 192, 2, 1),
(24, '2025-01-12', '20:12:00', '2025-01-12 17:12:51', 1, 192, 1, 1),
(6, '2025-01-13', '22:45:00', '2025-01-12 13:45:39', 2, 194, 2, 1),
(7, '2025-01-12', '16:45:00', '2025-01-12 13:46:06', 3, 195, 1, 2),
(8, '2025-01-12', '19:46:00', '2025-01-12 13:47:08', 3, 196, 1, 2),
(9, '2025-01-12', '16:47:00', '2025-01-12 13:47:38', 3, 195, 2, 2),
(10, '2025-01-13', '16:48:00', '2025-01-12 13:48:16', 3, 196, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_recovery_requests`
--

DROP TABLE IF EXISTS `password_recovery_requests`;
CREATE TABLE IF NOT EXISTS `password_recovery_requests` (
  `request_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `recovery_token` varchar(32) NOT NULL,
  `expiration_time` datetime NOT NULL,
  `is_used` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`request_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_recovery_requests`
--

INSERT INTO `password_recovery_requests` (`request_id`, `user_id`, `recovery_token`, `expiration_time`, `is_used`) VALUES
(1, 3, 'c1eef9d93902ff77d1ac254b2a184503', '2025-01-13 12:13:19', 0),
(2, 3, '74ea0a6c795f67531ef1431c40068057', '2025-01-13 12:18:45', 1),
(3, 3, '0741f58974a7acfae46a82c7ac04750f', '2025-01-13 12:22:46', 1),
(4, 3, '283a60e25100376be2853b4460f9226d', '2025-01-13 12:41:58', 1),
(5, 4, '515e53b1cc6e8e75ac23e137d9712477', '2025-01-13 12:52:25', 0),
(6, 4, '8933841b7c56e50b29031e5918dc47b1', '2025-01-13 12:55:35', 0),
(7, 4, 'affd096fa3ee2962626306b122ca6d35', '2025-01-13 13:03:46', 0),
(8, 4, '95a46758b419649599373e12a41baa84', '2025-01-13 13:03:53', 0),
(9, 4, '5c9217711a0cbf26ae14384ccc181ce0', '2025-01-13 13:04:24', 0),
(10, 4, '53a86fd4377582a3538e59fcea074c9f', '2025-01-13 13:06:05', 1),
(11, 4, '062cc593cfe3429620279eea6cda986b', '2025-01-13 13:13:20', 0),
(12, 4, '0fee89fb8d753326c8ec6dc6fe360e32', '2025-01-13 13:14:18', 1),
(13, 4, 'c17bf20cf9833d15d0c91f64e277d93d', '2025-01-13 13:14:20', 0),
(14, 3, '4204b73289beab1d12f3d3acfeb34d33', '2025-01-14 07:12:20', 0),
(15, 3, '2b86e3169bf654f7918effc8dcd9094b', '2025-01-14 07:13:09', 0),
(16, 3, '59d27e072ec0afb4ebff584d60de8fcc', '2025-01-14 07:13:44', 0),
(17, 3, 'f62a289f974d5b5c2c409b1661045139', '2025-01-14 07:14:25', 0),
(18, 3, 'fb18b2a372ed6512969ec170e39be436', '2025-01-14 07:17:33', 0),
(19, 4, 'c809ae0a8b3d294401a20ea5b2cc8927', '2025-01-14 07:19:03', 0),
(20, 4, '322a776a9ad51973cbcbc49242d8ee8f', '2025-01-14 07:19:05', 0),
(21, 4, 'f9ccd8d1b8832959cffac86c293225b5', '2025-01-14 07:19:24', 0),
(22, 4, '03fd40b5b4ab618c9672f8917f44d9fc', '2025-01-14 07:19:26', 0),
(23, 3, 'ad3d268d24d5c723fadbc1a2a254b9a8', '2025-01-14 07:31:30', 0),
(24, 3, '5476672bd4e893a728e4b237e6bf5e63', '2025-01-14 07:31:32', 0);

-- --------------------------------------------------------

--
-- Table structure for table `posted_exam_schedule`
--

DROP TABLE IF EXISTS `posted_exam_schedule`;
CREATE TABLE IF NOT EXISTS `posted_exam_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `exam_date` date NOT NULL,
  `exam_time` time NOT NULL,
  `classroom_id` int NOT NULL,
  `section_id` int NOT NULL,
  `year_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `classroom_id` (`classroom_id`),
  KEY `section_id` (`section_id`),
  KEY `year_id` (`year_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posted_exam_schedule`
--

INSERT INTO `posted_exam_schedule` (`id`, `course_id`, `exam_date`, `exam_time`, `classroom_id`, `section_id`, `year_id`) VALUES
(59, 194, '2025-01-12', '21:43:00', 1, 1, 1),
(60, 192, '2025-01-13', '16:44:00', 2, 2, 1),
(61, 192, '2025-01-12', '20:12:00', 1, 1, 1),
(62, 194, '2025-01-13', '22:45:00', 2, 2, 1),
(63, 195, '2025-01-12', '16:45:00', 3, 1, 2),
(64, 196, '2025-01-12', '19:46:00', 3, 1, 2),
(65, 195, '2025-01-12', '16:47:00', 3, 2, 2),
(66, 196, '2025-01-13', '16:48:00', 3, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `posted_schedule`
--

DROP TABLE IF EXISTS `posted_schedule`;
CREATE TABLE IF NOT EXISTS `posted_schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `section_id` int NOT NULL,
  `instructor_id` int NOT NULL,
  `classroom_id` int NOT NULL,
  `entry_year` int NOT NULL,
  `day_of_week` varchar(10) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  KEY `course_id` (`course_id`),
  KEY `section_id` (`section_id`),
  KEY `instructor_id` (`instructor_id`),
  KEY `classroom_id` (`classroom_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posted_schedule`
--

INSERT INTO `posted_schedule` (`schedule_id`, `course_id`, `section_id`, `instructor_id`, `classroom_id`, `entry_year`, `day_of_week`, `start_time`, `end_time`, `created_at`) VALUES
(127, 196, 3, 1, 1, 2013, 'Thursday', '08:00:00', '11:00:00', '2025-01-12 06:00:11'),
(128, 195, 1, 3, 1, 2013, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(129, 193, 2, 3, 1, 2012, 'Friday', '09:00:00', '10:00:00', '2025-01-12 06:00:11'),
(130, 196, 2, 1, 1, 2013, 'Tuesday', '08:00:00', '11:00:00', '2025-01-12 06:00:11'),
(131, 196, 1, 1, 1, 2013, 'Wednesday', '08:00:00', '11:00:00', '2025-01-12 06:00:11'),
(132, 192, 2, 1, 1, 2012, 'Thursday', '11:00:00', '13:00:00', '2025-01-12 06:00:11'),
(133, 195, 2, 3, 2, 2013, 'Wednesday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(134, 192, 1, 1, 1, 2012, 'Wednesday', '11:00:00', '13:00:00', '2025-01-12 06:00:11'),
(135, 194, 3, 8, 1, 2012, 'Monday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(136, 194, 2, 8, 2, 2012, 'Thursday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(137, 194, 1, 8, 2, 2012, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(138, 193, 3, 3, 2, 2012, 'Wednesday', '09:00:00', '10:00:00', '2025-01-12 06:00:11'),
(139, 193, 1, 3, 2, 2012, 'Monday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(140, 192, 3, 1, 3, 2012, 'Monday', '08:00:00', '10:00:00', '2025-01-12 06:00:11'),
(141, 195, 3, 3, 1, 2013, 'Friday', '10:00:00', '11:00:00', '2025-01-12 06:00:11'),
(142, 194, 1, 1, 1, 2014, 'Wednesday', '13:00:00', '14:00:00', '2025-01-12 06:00:11'),
(143, 195, 2, 3, 2, 2014, 'Wednesday', '10:00:00', '11:00:00', '2025-01-12 06:00:11'),
(144, 195, 1, 3, 1, 2014, 'Friday', '11:00:00', '12:00:00', '2025-01-12 06:00:11'),
(145, 194, 2, 1, 3, 2014, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(146, 193, 1, 11, 3, 2014, 'Wednesday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(147, 193, 2, 11, 4, 2014, 'Friday', '08:00:00', '09:00:00', '2025-01-12 06:00:11'),
(148, 192, 1, 13, 2, 2017, 'Friday', '09:00:00', '11:00:00', '2025-01-12 06:00:11'),
(149, 192, 1, 13, 4, 2016, 'Monday', '08:00:00', '10:00:00', '2025-01-12 06:00:11'),
(150, 192, 1, 13, 3, 2014, 'Thursday', '08:00:00', '10:00:00', '2025-01-12 06:00:11');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
CREATE TABLE IF NOT EXISTS `sections` (
  `section_id` int NOT NULL AUTO_INCREMENT,
  `section_name` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`section_id`, `section_name`, `created_at`) VALUES
(1, 'SE_sec_1', '2025-01-07 14:56:16'),
(2, 'SE_sec_2', '2025-01-08 07:52:29'),
(3, 'SE_sec_3', '2025-01-08 07:52:33'),
(4, 'SE_sec_4', '2025-01-08 07:52:39');

-- --------------------------------------------------------

--
-- Table structure for table `section_enrollment`
--

DROP TABLE IF EXISTS `section_enrollment`;
CREATE TABLE IF NOT EXISTS `section_enrollment` (
  `enrollment_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `section_id` int NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  KEY `student_id` (`student_id`),
  KEY `section_id` (`section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `section_enrollment`
--

INSERT INTO `section_enrollment` (`enrollment_id`, `student_id`, `section_id`) VALUES
(3, 12, 2),
(2, 10, 1),
(4, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `useractivities`
--

DROP TABLE IF EXISTS `useractivities`;
CREATE TABLE IF NOT EXISTS `useractivities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `activity_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `useractivities`
--

INSERT INTO `useractivities` (`id`, `user_id`, `activity`, `activity_time`) VALUES
(22, 5, 'Changed status for user: ashu to inactive', '2025-01-07 12:14:33'),
(23, 6, 'Registered user: abrham (Username: abrham)', '2025-01-07 12:16:48'),
(24, 6, 'Updated user: abrham. Changes: Role changed from \'instructor\' to \'admin\', Department changed from \'1\' to \'1\'', '2025-01-07 12:18:01'),
(25, 5, 'Updated user: ashu. Changes: Role changed from \'dept_head\' to \'student\', Department changed from \'3\' to \'3\'', '2025-01-07 12:18:19'),
(21, 5, 'Updated user: ashu. Changes: Role changed from \'student\' to \'dept_head\', Department changed from \'3\' to \'3\'', '2025-01-07 12:11:50'),
(19, 4, 'Updated user: Mhret Alemnew. Changes: Department changed from \'2\' to \'4\'', '2025-01-07 11:37:13'),
(20, 3, 'Changed status for user: Alemnew Dems to inactive', '2025-01-07 11:37:48'),
(26, 5, 'Deleted user: ashu', '2025-01-07 12:23:52'),
(27, 2, 'Changed status for user: Belay Zeleke to inactive', '2025-01-07 12:35:44'),
(28, 2, 'Changed status for user: Belay Zeleke to active', '2025-01-07 12:35:47'),
(29, 3, 'Updated user: Alemnew Dems. Changes: Department changed from \'1\' to \'3\'', '2025-01-07 12:44:50'),
(30, 3, 'Changed status for user: Alemnew Dems to active', '2025-01-07 12:58:15'),
(31, 3, 'Updated user: Alemnew Dems. Changes: Department changed from \'3\' to \'Computer Science\'', '2025-01-07 13:03:06'),
(32, 3, 'Updated user: Alemnew Dems. Changes: Department changed from \'Computer Science\' to \'Mathematics\'', '2025-01-07 13:09:17'),
(33, 10, 'Deleted department ID: 7', '2025-01-07 13:57:56'),
(34, 10, 'Updated department ID: 5', '2025-01-07 13:58:39'),
(35, 10, 'Deleted department: Economics', '2025-01-07 14:00:29'),
(36, 10, 'Added course: Introduction to Programming_01', '2025-01-07 14:06:09'),
(37, 10, 'Updated course: Introduction to Programming_01 to Introduction to Programming', '2025-01-07 14:06:16'),
(38, 10, 'Deleted classroom: Room E', '2025-01-07 14:12:03'),
(39, 10, 'Updated classroom: Room D to Room F', '2025-01-07 14:12:38'),
(40, 1, 'Updated schedule ID: 2', '2025-01-07 16:00:58'),
(41, 7, 'Registered user: Eyuel Alemnew (Username: eyuel)', '2025-01-07 16:49:38'),
(42, 9, 'Registered user: sam (Username: sam)', '2025-01-09 12:32:12'),
(43, 10, 'Registered user: Bereket Lemesa (Username: beki)', '2025-01-09 13:26:13'),
(44, 11, 'Registered user: Natnael Andatge (Username: natnael_instruct)', '2025-01-09 17:18:13'),
(45, 7, 'Updated user: Eyuel Alemnew. Changes: Department changed from \'Unknown\' to \'Computer Science\'', '2025-01-09 17:57:32'),
(46, 7, 'Updated user: Eyuel Alemnew. Changes: Department changed from \'Unknown\' to \'Computer Science\'', '2025-01-09 17:57:48'),
(47, 7, 'Updated user: Eyuel Alemnew. Changes: Department changed from \'Unknown\' to \'Computer Science\'', '2025-01-09 17:57:56'),
(48, 12, 'Registered user: habibity (Username: habibity)', '2025-01-10 08:51:59'),
(49, 13, 'Registered user: habibityinstr (Username: habibityinstr)', '2025-01-10 08:52:35'),
(50, 14, 'Registered user: habibityDephead (Username: habibityDephead)', '2025-01-10 08:53:19'),
(51, 1, 'Registered user: instructor1 (Username: instructor1)', '2025-01-12 14:21:50'),
(52, 2, 'Registered user: instructor2 (Username: instructor2)', '2025-01-12 14:22:15'),
(53, 3, 'Registered user: admin1 (Username: admin1)', '2025-01-12 14:22:54'),
(54, 4, 'Registered user: student1 (Username: student1)', '2025-01-12 14:23:27'),
(55, 5, 'Registered user: student2 (Username: student2)', '2025-01-12 14:23:48'),
(56, 6, 'Registered user: depthead1 (Username: depthead1)', '2025-01-12 14:24:23'),
(57, 7, 'Registered user: registrar (Username: registrar)', '2025-01-12 14:24:53'),
(58, 5, 'Deleted user: student2', '2025-01-12 14:25:27'),
(59, 1, 'Restore database', '2025-01-12 14:42:48'),
(60, 1, 'Backup database', '2025-01-12 14:42:53'),
(61, 3, 'Deleted user: admin1', '2025-01-13 11:22:56'),
(62, 8, 'Registered user: admin1 (Username: admin1)', '2025-01-13 11:23:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','instructor','dept_head','assistant_registrar','admin') NOT NULL,
  `department_id` int DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `full_name`, `password`, `role`, `department_id`, `status`, `created_at`) VALUES
(1, 'instructor1', 'instructor1@gmail.com', 'instructor1', '$2y$10$vzZLr3xYcyqN6ZXrvv7leucrrUDhBQANfRH2gsIb55dqYecH3WX3.', 'instructor', 1, 'active', '2025-01-12 11:21:50'),
(2, 'instructor2', 'instructor2@gmail.com', 'instructor2', '$2y$10$JbMOq4KcQbDrw4PtQBLa8ev3V5Z/ooLfKH8qd4/hIhAhDVGIe6STC', 'instructor', 1, 'active', '2025-01-12 11:22:15'),
(4, 'student1', 'student@gmail.com', 'student1', '$2y$10$QrSMs6t070pTAS55Agg0GuZcz5JQnOt.AqLecjLKgHN3V69y4zUc2', 'student', NULL, 'active', '2025-01-12 11:23:27'),
(5, 'student2', 'student2@gmail.com', 'student2', '$2y$10$nWd2sfZxiudFFVg8bxW9iuGH9cUKW7lq8Ds5K6Skq3xifZblG8Fw2', 'student', 1, 'active', '2025-01-12 11:23:48'),
(6, 'depthead1', 'depthead1@gmail.com', 'depthead1', '$2y$10$b25ZIcdjz/KP7QT1fcU1y.JMy67hVWY7wlIFAB/9E/vmMshKrSv4u', 'dept_head', 1, 'active', '2025-01-12 11:24:23'),
(7, 'registrar', 'registrar@gmail.com', 'registrar', '$2y$10$1tryFoT2/EaXBv44kaPjjOCKQEcVq7lxFrVOmeLpXK3pkHBfoJotW', 'assistant_registrar', NULL, 'active', '2025-01-12 11:24:53'),
(8, 'admin1', 'admin@gmail.com', 'admin1', '$2y$10$SOwGbEn3.uJk35Zywo32Wup4zCoqtEdh.7DejePKBTeyalhDY3.Iq', 'admin', NULL, 'active', '2025-01-13 08:23:24');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
