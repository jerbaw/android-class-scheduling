<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the user ID from the session
if (!isset($_SESSION['user_id'])) {
    die("User not logged in.");
}

$user_id = $_SESSION['user_id'];
$department_id = null;

// Get department ID from the users table
$dept_query = "SELECT department_id FROM users WHERE id = ?";
$stmt = $conn->prepare($dept_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $department_id = $row['department_id'];
}

// Fetch all courses and their exam schedules for the department
$exam_query = "
    SELECT pes.*, c.course_name, cl.room_name, y.year, s.section_name
    FROM posted_exam_schedule pes
    JOIN courses c ON pes.course_id = c.course_id
    JOIN classrooms cl ON pes.classroom_id = cl.classroom_id
    JOIN entry_year y ON pes.year_id = y.year_id
    JOIN sections s ON pes.section_id = s.section_id
    WHERE c.department_id = ?
    ORDER BY y.year, pes.exam_date, pes.exam_time";

$stmt = $conn->prepare($exam_query);
$stmt->bind_param("i", $department_id);
$stmt->execute();
$result = $stmt->get_result();

$exams_by_year = [];
while ($row = $result->fetch_assoc()) {
    $exams_by_year[$row['year']][] = $row;
}

// Handle CSV download
if (isset($_POST['download'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="posted_exam_schedule.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Year', 'Course Name', 'Section', 'Exam Date', 'Exam Time', 'Classroom']); // Column headers

    foreach ($exams_by_year as $year => $exams) {
        foreach ($exams as $exam) {
            fputcsv($output, [
                $year,
                $exam['course_name'],
                $exam['section_name'],
                $exam['exam_date'],
                $exam['exam_time'],
                $exam['room_name']
            ]);
        }
    }

    fclose($output);
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posted Exam Schedule</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">

    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold mb-6 text-center">Department Exam Schedule</h1>

        <?php if (empty($exams_by_year)): ?>
            <div class="bg-yellow-100 text-yellow-700 p-4 rounded mb-4">
                No exams scheduled for your department.
            </div>
        <?php else: ?>
            <div class="flex justify-between mb-4">
                <form method="POST">
                    <input type="hidden" name="download" value="1">
                    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                        Download Schedule as CSV
                    </button>
                </form>
            </div>
            <?php foreach ($exams_by_year as $year => $exams): ?>
                <h2 class="text-2xl font-semibold mb-4">Entry Year: <?php echo htmlspecialchars($year); ?></h2>
                <div class="bg-white shadow-md rounded-lg p-4 mb-6">
                    <table class="table-auto w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="px-4 py-2">Course Name</th>
                                <th class="px-4 py-2">Section</th>
                                <th class="px-4 py-2">Exam Date</th>
                                <th class="px-4 py-2">Exam Time</th>
                                <th class="px-4 py-2">Classroom</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($exams as $exam): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($exam['course_name']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($exam['section_name']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($exam['exam_date']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($exam['exam_time']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($exam['room_name']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

</body>
</html>