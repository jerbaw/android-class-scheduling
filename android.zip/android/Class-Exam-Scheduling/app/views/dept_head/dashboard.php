<?php
session_start();

// Check if the user is logged in and is a department head
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dept_head') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Welcome message
$welcomeMessage = "Welcome, " . htmlspecialchars($_SESSION['full_name']) . "!";

// Logout functionality
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department Head Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .card {
            transition: transform 0.3s, box-shadow 0.3s; /* Animation effect */
            border: none;
            border-radius: 10px;
        }
        .card:hover {
            transform: translateY(-10px); /* Lift effect on hover */
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2); /* Shadow effect */
        }
        .container {
            margin-top: 50px;
        }
        .welcome-message {
            font-size: 1.5rem;
            color: #28a745;
            margin-bottom: 30px;
        }
        .card-title {
            color: #007bff;
        }
        .card-icon {
            font-size: 40px;
            color: #007bff;
            margin-bottom: 15px;
        }
        .logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        @media (max-width: 768px) {
            .welcome-message {
                font-size: 1.2rem; /* Slightly smaller on mobile */
            }
        }
    </style>
</head>
<body>
    <div class="container text-center position-relative">
        <h1 class="mb-4">Department Head Dashboard</h1>
        <div class="welcome-message"><?php echo $welcomeMessage; ?></div>
        <a href="?logout=true" class="btn btn-danger logout-btn">Logout</a>
        <div class="row">
            <div class="col-sm-6 col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <i class="fas fa-calendar-alt card-icon"></i>
                        <h5 class="card-title">Class Schedule</h5>
                        <p class="card-text">View class schedules for your department.</p>
                        <a href="/Class-Exam-Scheduling/app/views/dept_head/class_schedule.php" class="btn btn-primary">Go to Schedule</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <i class="fas fa-file-alt card-icon"></i>
                        <h5 class="card-title">Exam Schedule</h5>
                        <p class="card-text">Check upcoming exams for your department.</p>
                        <a href="/Class-Exam-Scheduling/app/views/dept_head/exam_schedule.php" class="btn btn-primary">Go to Exam Schedule</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <i class="fas fa-comment-dots card-icon"></i>
                        <h5 class="card-title">Send Complaint</h5>
                        <p class="card-text">Submit a complaint regarding any issues.</p>
                        <a href="/Class-Exam-Scheduling/app/views/dept_head/submit_complaint.php" class="btn btn-primary">Send Complaint</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>