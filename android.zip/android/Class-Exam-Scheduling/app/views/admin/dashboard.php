<?php
session_start();

// // Check if the user is logged in and is an admin
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     // Redirect to login page if not logged in or not an admin
//     header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
//     exit();
// }
// Database connection
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total users
$totalUsersResult = $conn->query("SELECT COUNT(*) AS total FROM users");
$totalUsers = $totalUsersResult->fetch_assoc()['total'];

// Fetch active users
$activeUsersResult = $conn->query("SELECT COUNT(*) AS active FROM users WHERE status = 'active'");
$activeUsers = $activeUsersResult->fetch_assoc()['active'];

// Calculate inactive users
$inactiveUsers = $totalUsers - $activeUsers;

// Fetch user counts by role
$roleCounts = [
    'student' => 0,
    'instructor' => 0,
    'dept_head' => 0,
    'admin' => 0,
];

// Loop through roles and fetch counts
foreach ($roleCounts as $role => &$count) {
    $result = $conn->query("SELECT COUNT(*) AS count FROM users WHERE role = '". $conn->real_escape_string($role) ."'");
    if ($result) {
        $count = $result->fetch_assoc()['count'];
    }
}

// Fetch recent activities
$recentActivities = [];
$activityResult = $conn->query("SELECT activity, activity_time FROM useractivities ORDER BY activity_time DESC LIMIT 5");
while ($row = $activityResult->fetch_assoc()) {
    $recentActivities[] = $row;
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        body {
            font-family: "Roboto", sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
        }
        h2 {
            margin: -15px 0 70px 0;
            font-size: 50px;
        }
        .card {
            margin-bottom: 20px;
            border: none;
        }
        .card.total-users { background-color: #007bff; color: white; }
        .card.active-users { background-color: #28a745; color: white; }
        .card.inactive-users { background-color: #dc3545; color: white; }
        .card.role-card { color: white; }
        .card.students { background-color: #17a2b8; }
        .card.instructors { background-color: #ffc107; color: black; }
        .card.department-heads { background-color: #a1a0a0; }
        .card.admins { background-color: #6f42c1; }
        .card-icon { font-size: 2em; margin-bottom: 10px; }
        .activity-time { font-size: 0.85em; color: #6c757d; }
        @media (max-width: 768px) { .card-body h5 { font-size: 1.2em; } }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center"><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card total-users text-center">
                    <div class="card-body">
                        <i class="fas fa-users card-icon"></i>
                        <h5 class="card-title">Total Users</h5>
                        <p class="card-text"><?= $totalUsers ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card active-users text-center">
                    <div class="card-body">
                        <i class="fas fa-user-check card-icon"></i>
                        <h5 class="card-title">Active Users</h5>
                        <p class="card-text"><?= $activeUsers ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card inactive-users text-center">
                    <div class="card-body">
                        <i class="fas fa-user-times card-icon"></i>
                        <h5 class="card-title">Inactive Users</h5>
                        <p class="card-text"><?= $inactiveUsers ?></p>
                    </div>
                </div>
            </div>
        </div>

        <h3 class="mt-4">Users by Role</h3>
        <div class="row">
            <div class="col-md-3">
                <div class="card role-card students text-center">
                    <div class="card-body">
                        <i class="fas fa-user-graduate card-icon"></i>
                        <h5 class="card-title">Students</h5>
                        <p class="card-text"><?= $roleCounts['student'] ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card role-card instructors text-center">
                    <div class="card-body">
                        <i class="fas fa-chalkboard-teacher card-icon"></i>
                        <h5 class="card-title">Instructors</h5>
                        <p class="card-text"><?= $roleCounts['instructor'] ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card role-card department-heads text-center">
                    <div class="card-body">
                        <i class="fas fa-user-tie card-icon"></i>
                        <h5 class="card-title">Department Heads</h5>
                        <p class="card-text"><?= $roleCounts['dept_head'] ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card role-card admins text-center">
                    <div class="card-body">
                        <i class="fas fa-user-shield card-icon"></i>
                        <h5 class="card-title">Admins</h5>
                        <p class="card-text"><?= $roleCounts['admin'] ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header">Recent Activity</div>
            <div class="card-body">
                <ul id="activity-list" class="list-group">
                    <?php if (empty($recentActivities)): ?>
                        <p>No recent activity to display.</p>
                    <?php else: ?>
                        <?php foreach ($recentActivities as $activity): ?>
                            <li class="list-group-item">
                                <strong><?= htmlspecialchars($activity['activity']) ?></strong>
                                <div class="activity-time"><?= date('Y-m-d H:i:s', strtotime($activity['activity_time'])) ?></div>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>