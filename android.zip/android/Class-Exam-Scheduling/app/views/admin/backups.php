<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'class_and_exam_scheduling';
$backupDir = 'backup/';

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure backup directory exists
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0777, true);
}

// Function to get list of all tables
function getTables($conn) {
    $tables = [];
    $query = "SHOW TABLES";
    $result = $conn->query($query);
    while ($row = $result->fetch_array()) {
        $tables[] = $row[0];
    }
    return $tables;
}

// Function to log activity
function logActivity($conn, $user_id, $activity) {
    $query = "INSERT INTO useractivities (user_id, activity, activity_time) VALUES ('$user_id', '$activity', NOW())";
    $conn->query($query);
}

// Function to backup database
function backupDatabase($conn, $tables, $backupDir, $user_id) {
    $backupFile = $backupDir . 'database_backup_' . date("Y-m-d_H-i-s") . '.sql';
    $fp = fopen($backupFile, 'w');
    if ($fp === false) {
        echo "<div class='alert alert-danger'>Error opening file for writing.</div>";
        return;
    }

    foreach ($tables as $table) {
        $query = "SELECT * FROM $table";
        $result = $conn->query($query);

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $values = array_map(function($value) use ($conn) {
                    return is_null($value) ? 'NULL' : "'" . $conn->real_escape_string($value) . "'";
                }, array_values($row));
                $rowString = "INSERT INTO $table (" . implode(", ", array_keys($row)) . ") VALUES (" . implode(", ", $values) . ");\n";
                fwrite($fp, $rowString);
            }
        }
    }

    fclose($fp);
    logActivity($conn, $user_id, "Backup database");
    echo "<div class='alert alert-success'>Backup of database was successful!</div>";
}

// Function to restore database
function restoreDatabase($conn, $backupFile, $user_id) {
    $tables = getTables($conn);
    foreach ($tables as $table) {
        $conn->query("TRUNCATE TABLE $table");
    }

    $fp = fopen($backupFile, 'r');
    if ($fp === false) {
        echo "<div class='alert alert-danger'>Error opening file for reading.</div>";
        return;
    }

    $queries = fread($fp, filesize($backupFile));
    fclose($fp);

    if ($conn->multi_query($queries)) {
        do {
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->more_results() && $conn->next_result());
        logActivity($conn, $user_id, "Restore database");
        echo "<div class='alert alert-success'>Restore of database was successful!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error restoring database: " . $conn->error . "</div>";
    }
}

// Function to get list of backup files
function getBackupFiles($backupDir) {
    return array_diff(scandir($backupDir), array('.', '..'));
}

// Check for actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tables = getTables($conn);
    $user_id = 1; // Replace with the actual user ID performing the action
    if (isset($_POST['backup'])) {
        backupDatabase($conn, $tables, $backupDir, $user_id);
    } elseif (isset($_POST['restore']) && isset($_POST['backupFile'])) {
        restoreDatabase($conn, $_POST['backupFile'], $user_id);
    }
}

$backupFiles = getBackupFiles($backupDir);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Backup & Restore</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7f8;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 350px;
            text-align: center;
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #007bff;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            cursor: pointer;
            margin: 5px 0;
            transition: background-color 0.3s, transform 0.3s;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        button:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
        button i {
            margin-right: 8px;
        }
        select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
            background-color: #f9f9f9;
        }
        .alert {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Backup & Restore</h1>
        <form method="post">
            <button type="submit" name="backup"><i class="fas fa-database"></i>Backup</button>
            <label for="backupFile">Select Backup File:</label>
            <select id="backupFile" name="backupFile">
                <?php foreach ($backupFiles as $file): ?>
                    <option value="<?php echo $backupDir . $file; ?>"><?php echo $file; ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" name="restore"><i class="fas fa-undo"></i>Restore</button>
        </form>
    </div>
</body>
</html>