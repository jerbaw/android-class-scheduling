<?php
session_start();

// // Check if the user is logged in and is an admin
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     // Redirect to login page if not logged in or not an admin
//     header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
//     exit();
// }
// Database connection
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize message variable
$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $full_name = $_POST['full_name'];
    $department_id = !empty($_POST['department_id']) ? $_POST['department_id'] : null;

    // Validate input
    if (empty($username) || empty($password) || empty($email) || empty($full_name) || empty($role)) {
        $message = "All fields are required.";
    } else {
        // Check if username or email already exists
        $checkUserSql = "SELECT * FROM Users WHERE username = ? OR email = ?";
        $stmt = $conn->prepare($checkUserSql);
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $message = "Username or email already exists.";
        } else {
            // Encrypt the password
            $encryptedPassword = password_hash($password, PASSWORD_BCRYPT);

            // Insert new user into database
            $sql = "INSERT INTO Users (username, password, email, role, full_name, department_id) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssi", $username, $encryptedPassword, $email, $role, $full_name, $department_id);

            if ($stmt->execute()) {
                // Log the activity
                $activity = "Registered user: $full_name (Username: $username)";
                $activitySql = "INSERT INTO useractivities (user_id, activity, activity_time) VALUES (?, ?, NOW())";
                
                // Assuming you have a way to get the newly created user's ID
                $userId = $conn->insert_id; // Get the ID of the last inserted user
                
                $activityStmt = $conn->prepare($activitySql);
                $activityStmt->bind_param("is", $userId, $activity);
                $activityStmt->execute();
                $activityStmt->close();

                $message = "User registered successfully.";
            } else {
                $message = "Error registering user: " . $stmt->error;
            }

            $stmt->close();
        }
    }
}

// Fetch all departments for the dropdown
$sql_departments = "SELECT * FROM departments";
$departments_result = $conn->query($sql_departments);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container my-5">
    <h1 class="text-center mb-5">
        <i class="fas fa-user-plus"></i> Register User
    </h1>

        <?php if ($message): ?>
            <div class="alert alert-info">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <!-- Registration Form -->
        <div class="card">
            <div class="card-header">Create Account</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" id="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" name="full_name" id="full_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" name="role" id="role" required>
                            <option value="student">Student</option>
                            <option value="instructor">Instructor</option>
                            <option value="dept_head">Department Head</option>
                            <option value="assistant_registrar">Assistant Registrar</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="department_id" class="form-label">Department</label>
                        <select class="form-select" name="department_id" id="department_id">
                            <option value="">Select Department</option>
                            <?php while ($dept = $departments_result->fetch_assoc()): ?>
                                <option value="<?= $dept['department_id'] ?>"><?= $dept['department_name'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Register</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>