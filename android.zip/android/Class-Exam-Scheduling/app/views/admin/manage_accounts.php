<?php
session_start();

// // Check if the user is logged in and is an admin
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     // Redirect to login page if not logged in or not an admin
//     header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
//     exit();
// }
// Database connection
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize search and filter variables
$search_full_name = isset($_POST['search_full_name']) ? $_POST['search_full_name'] : '';
$filter_role = isset($_POST['filter_role']) ? $_POST['filter_role'] : '';
$filter_status = isset($_POST['filter_status']) ? $_POST['filter_status'] : '';

// Construct SQL query with filters
$sql_users = "SELECT Users.*, departments.department_name FROM Users 
               LEFT JOIN departments ON Users.department_id = departments.department_id 
               WHERE (full_name LIKE ? OR email LIKE ?)";
$params = ['%' . $search_full_name . '%', '%' . $search_full_name . '%'];

if ($filter_role) {
    $sql_users .= " AND role = ?";
    $params[] = $filter_role;
}

if ($filter_status) {
    $sql_users .= " AND status = ?";
    $params[] = $filter_status;
}

// Prepare and execute the statement
$stmt = $conn->prepare($sql_users);
$stmt->bind_param(str_repeat('s', count($params)), ...$params);
$stmt->execute();
$users_result = $stmt->get_result();

// Fetch all departments for the dropdown
$sql_departments = "SELECT department_id, department_name FROM departments";
$departments_result = $conn->query($sql_departments);

// Handle edit and delete actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['editUser'])) {
        // Fetch current user data
        $userId = $_POST['user_id'];
        $sql = "SELECT * FROM Users WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $currentUser = $stmt->get_result()->fetch_assoc();

        // New values
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $status = $_POST['status'];
        $new_department_id = $_POST['department_id'];

        // Fetch the current department name
        $current_department_id = $currentUser['department_id'];
        $sql = "SELECT department_name FROM Departments WHERE department_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $current_department_id);
        $stmt->execute();
        $currentDepartmentResult = $stmt->get_result()->fetch_assoc();
        $current_department_name = $currentDepartmentResult ? $currentDepartmentResult['department_name'] : 'Unknown';

        // Fetch the new department name
        $sql = "SELECT department_name FROM departments WHERE department_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $new_department_id);
        $stmt->execute();
        $newDepartmentResult = $stmt->get_result()->fetch_assoc();
        $new_department_name = $newDepartmentResult ? $newDepartmentResult['department_name'] : 'Unknown';

        // Prepare update SQL
        $sql = "UPDATE Users SET full_name=?, email=?, role=?, status=?, department_id=? WHERE department_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssii", $full_name, $email, $role, $status, $new_department_id, $userId);
        $stmt->execute();

        // Log changes
        $changes = [];
        if ($currentUser['full_name'] !== $full_name) {
            $changes[] = "Full Name changed from '{$currentUser['full_name']}' to '$full_name'";
        }
        if ($currentUser['email'] !== $email) {
            $changes[] = "Email changed from '{$currentUser['email']}' to '$email'";
        }
        if ($currentUser['role'] !== $role) {
            $changes[] = "Role changed from '{$currentUser['role']}' to '$role'";
        }
        if ($currentUser['status'] !== $status) {
            $changes[] = "Status changed from '{$currentUser['status']}' to '$status'";
        }
        if ($current_department_id !== $new_department_id) {
            $changes[] = "Department changed from '$current_department_name' to '$new_department_name'";
        }

        // Construct log message
        $activity = "Updated user: $full_name. Changes: " . implode(", ", $changes);
        $stmt = $conn->prepare("INSERT INTO UserActivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $userId, $activity);
        $stmt->execute();
        
        // Refresh the page
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }



    if (isset($_POST['deleteUser'])) {
        // Delete user logic
        $userId = $_POST['user_id'];
        $sql = "SELECT full_name FROM Users WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $full_name = $user['full_name'];

        $sql = "DELETE FROM Users WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        // Log activity with full name
        $activity = "Deleted user: $full_name";
        $stmt = $conn->prepare("INSERT INTO UserActivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $userId, $activity);
        $stmt->execute();

        // Refresh the page
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    if (isset($_POST['toggleStatus'])) {
        // Toggle status logic
        $userId = $_POST['user_id'];
        $currentStatus = $_POST['current_status'] === 'active' ? 'inactive' : 'active';
        $sql = "UPDATE Users SET status=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $currentStatus, $userId);
        $stmt->execute();

        // Retrieve full name for logging
        $sql = "SELECT full_name FROM Users WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $full_name = $user['full_name'];

        // Log activity with full name
        $activity = "Changed status for user: $full_name to $currentStatus";
        $stmt = $conn->prepare("INSERT INTO UserActivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $userId, $activity);
        $stmt->execute();

        // Refresh the page
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            margin-bottom: 20px;
            border: none;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .status-active {
            color: green;
        }
        .status-inactive {
            color: red;
        }
        .btn-custom {
            transition: background-color 0.3s;
        }
        .btn-custom:hover {
            background-color: #0056b3;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container my-5">
    <h1 class="text-center mb-5">
    <i class="fas fa-users"></i> Manage Users
</h1>

        <!-- Search and Filter Form -->
        <form method="POST" class="mb-4">
            <div class="row">
                <div class="col">
                    <input type="text" class="form-control" name="search_full_name" placeholder="Search by Full Name or Email" value="<?= htmlspecialchars($search_full_name) ?>">
                </div>
                <div class="col">
                    <select class="form-select" name="filter_role">
                        <option value="">Filter by Role</option>
                        <option value="student" <?= $filter_role === 'student' ? 'selected' : '' ?>>Student</option>
                        <option value="instructor" <?= $filter_role === 'instructor' ? 'selected' : '' ?>>Instructor</option>
                        <option value="dept_head" <?= $filter_role === 'dept_head' ? 'selected' : '' ?>>Department Head</option>
                        <option value="assistant_registrar" <?= $filter_role === 'assistant_registrar' ? 'selected' : '' ?>>Assistant Registrar</option>
                        <option value="admin" <?= $filter_role === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                <div class="col">
                    <select class="form-select" name="filter_status">
                        <option value="">Filter by Status</option>
                        <option value="active" <?= $filter_status === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $filter_status === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </form>

        <div class="row">
            <?php while ($user = $users_result->fetch_assoc()): ?>
                <div class="col-md-4">
                    <div class="card p-3">
                        <h5 class="card-title"><?= $user['full_name'] ?></h5>
                        <p class="card-text">Email: <?= $user['email'] ?></p>
                        <p class="card-text">Role: <?= $user['role'] ?></p>
                        <p class="card-text">Department: <?= !empty($user['department_name']) ? $user['department_name'] : 'No Department' ?></p>
                        <p class="card-text status-<?= $user['status'] ?>"><?= ucfirst($user['status']) ?></p>
                        <div class="d-flex justify-content-between">
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal" 
                                    data-id="<?= $user['id'] ?>" data-fullname="<?= $user['full_name'] ?>" 
                                    data-email="<?= $user['email'] ?>" data-role="<?= $user['role'] ?>" 
                                    data-status="<?= $user['status'] ?>" data-department="<?= $user['department_id'] ?>">
                                <i class="bi bi-pencil"></i> Edit
                            </button>
                            <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal" 
                                    data-id="<?= $user['id'] ?>">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                            <form style="display:inline;" method="POST" action="">
                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                <input type="hidden" name="current_status" value="<?= $user['status'] ?>">
                                <button type="submit" name="toggleStatus" class="btn btn-secondary btn-sm <?= $user['status'] === 'active' ? 'btn-success' : 'btn-secondary' ?>">
    <?= $user['status'] === 'active' ? 'Deactivate' : 'Activate' ?>
</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Edit User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="user_id" id="editUserId">
                        <div class="mb-3">
                            <label for="editFullName" class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="full_name" id="editFullName" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="editEmail" required>
                        </div>
                        <div class="mb-3">
                            <label for="editRole" class="form-label">Role</label>
                            <select class="form-select" name="role" id="editRole" required>
                                <option value="student">Student</option>
                                <option value="instructor">Instructor</option>
                                <option value="dept_head">Department Head</option>
                                <option value="assistant_registrar">Assistant Registrar</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="editDepartment" class="form-label">Department</label>
                            <select class="form-select" name="department_id" id="editDepartment" >
                                <?php while ($department = $departments_result->fetch_assoc()): ?>
                                    <option value="<?= $department['department_id'] ?>"><?= $department['department_name'] ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="editStatus" class="form-label">Status</label>
                            <select class="form-select" name="status" id="editStatus" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="editUser" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete User Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">Delete User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this user?
                        <input type="hidden" name="user_id" id="deleteUserId">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="deleteUser" class="btn btn-danger">Delete</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var editModal = document.getElementById('editModal');
        editModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var userId = button.getAttribute('data-id');
            var fullName = button.getAttribute('data-fullname');
            var email = button.getAttribute('data-email');
            var role = button.getAttribute('data-role');
            var status = button.getAttribute('data-status');
            var departmentId = button.getAttribute('data-department');

            var editUserId = editModal.querySelector('#editUserId');
            var editFullName = editModal.querySelector('#editFullName');
            var editEmail = editModal.querySelector('#editEmail');
            var editRole = editModal.querySelector('#editRole');
            var editStatus = editModal.querySelector('#editStatus');
            var editDepartment = editModal.querySelector('#editDepartment');

            editUserId.value = userId;
            editFullName.value = fullName;
            editEmail.value = email;
            editRole.value = role;
            editStatus.value = status;
            editDepartment.value = departmentId;
        });

        var deleteModal = document.getElementById('deleteModal');
        deleteModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var userId = button.getAttribute('data-id');
            var deleteUserId = deleteModal.querySelector('#deleteUserId');
            deleteUserId.value = userId;
        });
    </script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>