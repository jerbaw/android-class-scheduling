<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Handle logout if the request is made
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_destroy(); // Destroy the session
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php"); // Redirect to the login page
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Modern Sidebar</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css" rel="stylesheet" />
    <style>
        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        /* Sidebar Styling */
        .sidebar {
            height: 100%;
            width: 80px;
            background-color: #1e1e2f;
            color: #ffffff;
            position: fixed;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px 0;
            transition: width 0.3s ease;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.2);
        }
        .sidebar.expanded {
            width: 250px;
        }
        .sidebar .logo {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 30px;
            margin-top: 60px;
            text-align: center;
            transition: all 0.3s ease;
        }
        .sidebar.expanded .logo {
            font-size: 1.8rem;
        }
        /* Hamburger Menu */
        .hamburger {
            position: absolute;
            left: 20px;
            top: 0;
            font-size: 1.5rem;
            color: #ffffff;
            cursor: pointer;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        /* Sidebar Links */
        .sidebar a {
            width: 100%;
            display: flex;
            align-items: center;
            padding: 15px 20px;
            text-decoration: none;
            color: #b2b2d8;
            font-size: 16px;
            font-weight: 500;
            transition: background-color 0.3s, color 0.3s;
        }
        .sidebar a i {
            font-size: 1.5rem;
            margin-right: 10px;
            transition: transform 0.3s;
        }
        .sidebar a span {
            display: none;
            transition: opacity 0.3s ease;
        }
        .sidebar.expanded a span {
            display: inline;
            opacity: 1;
        }
        .sidebar a:hover {
            background-color: #343a40;
            color: #ffffff;
        }
        .sidebar a.active {
            background-color: #007bff;
            color: #ffffff;
        }
        /* Logout Button */
        .logout-button {
            margin-top: auto;
            width: 100%;
            padding: 15px;
            text-align: center;
            background-color: #dc3545;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
        /* Main Content */
        .content {
            margin-left: 80px;
            padding: 20px;
            width: calc(100% - 80px);
            height: 100%;
            transition: margin-left 0.3s ease, width 0.3s ease;
        }
        .sidebar.expanded ~ .content {
            margin-left: 250px;
            width: calc(100% - 250px);
        }
        iframe {
            width: 100%;
            height: 100%;
            border: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <!-- Hamburger Menu -->
        <div class="hamburger" id="hamburger">
            <i class="bi bi-list"></i>
        </div>
        <div class="logo">Admin</div>

        <a href="#" onclick="loadPage('dashboard.php')" class="active">
            <i class="bi bi-house-door"></i><span>Dashboard</span>
        </a>
        <a href="#" onclick="loadPage('register_users.php')">
            <i class="bi bi-person-plus"></i><span>Register Users</span>
        </a>
        <a href="#" onclick="loadPage('manage_accounts.php')">
            <i class="bi bi-people"></i><span>Manage Users</span>
        </a>
        <a href="#" onclick="loadPage('backups.php')">
            <i class="bi bi-hdd"></i><span>Take Backup</span>
        </a>

        <!-- Logout Form -->
        <form method="POST" style="width: 100%;">
            <button type="submit" name="logout" class="logout-button">
                <i class="bi bi-box-arrow-right"></i> Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="content">
        <iframe src="dashboard.php" name="contentFrame"></iframe>
    </div>

    <script>
        // Sidebar toggle functionality
        document.addEventListener("DOMContentLoaded", () => {
            const sidebar = document.getElementById("sidebar");
            const hamburger = document.getElementById("hamburger");
            const links = document.querySelectorAll(".sidebar a");
            const iframe = document.querySelector("iframe");

            // Toggle sidebar
            hamburger.addEventListener("click", () => {
                sidebar.classList.toggle("expanded");
            });

            // Load page function
            function loadPage(page) {
                const iframe = document.querySelector("iframe");
                iframe.src = page;
                links.forEach(link => link.classList.remove("active"));
                const activeLink = [...links].find(link => link.getAttribute("onclick").includes(page));
                if (activeLink) activeLink.classList.add("active");
            }

            // Set up click event for links
            links.forEach(link => {
                link.addEventListener("click", (event) => {
                    event.preventDefault();
                    const page = link.getAttribute("onclick").match(/'(.*?)'/)[1];
                    loadPage(page);
                });
            });

            // Update active link when iframe loads
            iframe.addEventListener("load", () => {
                const currentPage = iframe.contentWindow.location.pathname.split("/").pop();
                links.forEach(link => {
                    link.classList.remove("active");
                    if (link.getAttribute("onclick").includes(currentPage)) {
                        link.classList.add("active");
                    }
                });
            });

            // Load the default page
            loadPage("dashboard.php");
        });
    </script>
</body>
</html>