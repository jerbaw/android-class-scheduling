<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Get the student's user ID
$user_id = $_SESSION['user_id'];

// Fetch entry years
$years_result = $conn->query("SELECT year_id, year FROM entry_year");

// Fetch the current entry year for the student
$current_year_query = "
    SELECT year_id FROM entry_year_enrollment WHERE student_id = ?
";
$stmt = $conn->prepare($current_year_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$current_year_result = $stmt->get_result();
$current_year = $current_year_result->fetch_assoc();
$current_year_id = $current_year ? $current_year['year_id'] : null;

// Handle entry year enrollment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_year'])) {
        $year_id = $_POST['year_id'];
        // Check if already enrolled in the selected year
        if ($current_year_id !== null) {
            // Update existing entry year
            $stmt = $conn->prepare("UPDATE entry_year_enrollment SET year_id = ? WHERE student_id = ?");
            $stmt->bind_param("ii", $year_id, $user_id);
            $stmt->execute();
            echo "<p class='success'>Successfully updated entry year.</p>";
        } else {
            // Insert new entry year
            $stmt = $conn->prepare("INSERT INTO entry_year_enrollment (student_id, year_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $user_id, $year_id);
            $stmt->execute();
            echo "<p class='success'>Successfully updated entry year.</p>";
        }
        $stmt->close();
        
        // Refresh the page after the update
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll Entry Year</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Roboto', sans-serif; background-color: #f4f4f4; color: #333; }
        .container { max-width: 600px; margin: 50px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); }
        h1 { text-align: center; color: #007BFF; }
        select, button { width: 100%; padding: 10px; margin: 10px 0; }
        button { background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        .success { color: green; text-align: center; }
        .current-year { margin-top: 20px; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Entry Year</h1>
        <form method="POST" action="">
            <label for="year_id">Select Year:</label>
            <select name="year_id" id="year_id" required>
                <?php while ($row = $years_result->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($row['year_id']); ?>" 
                        <?php echo $current_year_id == $row['year_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($row['year']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <button type="submit" name="update_year">Update</button>
        </form>

        <div class="current-year">
            <?php if ($current_year_id): ?>
                <p>Current Entry Year: 
                    <strong><?php 
                        // Reopen connection to fetch current year name
                        $conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");
                        $current_year_name_query = "SELECT year FROM entry_year WHERE year_id = ?";
                        $stmt = $conn->prepare($current_year_name_query);
                        $stmt->bind_param("i", $current_year_id);
                        $stmt->execute();
                        $current_year_name_result = $stmt->get_result();
                        $current_year_name = $current_year_name_result->fetch_assoc();
                        echo htmlspecialchars($current_year_name['year']); 
                        $stmt->close();
                        $conn->close(); // Close connection after use
                    ?></strong>
                </p>
            <?php else: ?>
                <p>No entry year set.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>