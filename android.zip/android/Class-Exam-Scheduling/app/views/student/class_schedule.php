<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Fetch the enrolled sections for the logged-in student
$student_id = $_SESSION['user_id'];
$enrolled_sections = $conn->query("
    SELECT section_id 
    FROM section_enrollment 
    WHERE student_id = '$student_id'
");

// Prepare an array to hold the enrolled section IDs
$section_ids = [];
if ($enrolled_sections) {
    while ($row = $enrolled_sections->fetch_assoc()) {
        $section_ids[] = $row['section_id'];
    }
}

// Fetch the enrolled entry years for the logged-in student
$enrolled_years = $conn->query("
    SELECT year_id 
    FROM entry_year_enrollment 
    WHERE student_id = '$student_id'
");

// Prepare an array to hold the enrolled year IDs
$year_ids = [];
if ($enrolled_years) {
    while ($row = $enrolled_years->fetch_assoc()) {
        $year_ids[] = $row['year_id'];
    }
}

// If the student is enrolled in any sections and years, fetch the schedules
$schedules = [];
if (!empty($section_ids) && !empty($year_ids)) {
    $section_ids_placeholder = implode(',', array_map('intval', $section_ids));
    $year_ids_placeholder = implode(',', array_map('intval', $year_ids));

    // Join with entry_year table to filter by entry_year
    $schedules = $conn->query("
        SELECT 
            ps.schedule_id,
            c.course_id,
            c.course_name,
            s.section_id,
            s.section_name,
            u.id AS instructor_id,
            u.full_name AS instructor_name,
            cr.classroom_id,
            cr.room_name,
            ps.entry_year,
            ps.day_of_week,
            ps.start_time,
            ps.end_time
        FROM 
            posted_schedule ps
        INNER JOIN 
            courses c ON ps.course_id = c.course_id
        INNER JOIN 
            sections s ON ps.section_id = s.section_id
        INNER JOIN 
            users u ON ps.instructor_id = u.id
        INNER JOIN 
            classrooms cr ON ps.classroom_id = cr.classroom_id
        WHERE 
            s.section_id IN ($section_ids_placeholder) AND
            ps.entry_year IN (SELECT year FROM entry_year WHERE year_id IN ($year_ids_placeholder))
        ORDER BY 
            ps.entry_year, 
            FIELD(ps.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), 
            c.course_name
    ");
}

// Prepare section and year display
$display_section = !empty($section_ids) ? htmlspecialchars(implode(', ', $section_ids)) : 'N/A';
$display_year = !empty($year_ids) ? htmlspecialchars(implode(', ', $year_ids)) : 'N/A';

// Download CSV logic
if (isset($_GET['download'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="schedules.csv"');
    $output = fopen('php://output', 'w');

    // Add CSV header
    fputcsv($output, ['Course ID', 'Course Name', 'Instructor', 'Classroom', 'Day', 'Start Time', 'End Time']);

    if ($schedules && $schedules->num_rows > 0) {
        while ($row = $schedules->fetch_assoc()) {
            fputcsv($output, [
                $row['course_id'],
                $row['course_name'],
                $row['instructor_name'],
                $row['room_name'],
                $row['day_of_week'],
                $row['start_time'],
                $row['end_time']
            ]);
        }
    }
    fclose($output);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Schedules</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Class Schedules</h1>
        
        <?php 
        $current_year = null;

        if ($schedules && $schedules->num_rows > 0) {
            while ($row = $schedules->fetch_assoc()) {
                // Check for a new Entry Year
                if ($current_year !== $row['entry_year']) {
                    if ($current_year !== null) echo '</tbody></table>'; // Close previous table
                    $current_year = $row['entry_year'];
                    echo "<h3 class='mt-4'>Entry Year: " . htmlspecialchars($current_year) . "</h3>";
                    echo '<table class="table table-bordered mt-3">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Course ID</th>
                                    <th>Course Name</th>
                                    <th>Instructor</th>
                                    <th>Classroom</th>
                                    <th>Day</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                </tr>
                            </thead>
                            <tbody>';
                }
                
                // Output the schedule row
                echo "<tr>
                        <td>" . htmlspecialchars($row['course_id']) . "</td>
                        <td>" . htmlspecialchars($row['course_name']) . "</td>
                        <td>" . htmlspecialchars($row['instructor_name']) . "</td>
                        <td>" . htmlspecialchars($row['room_name']) . "</td>
                        <td>" . htmlspecialchars($row['day_of_week']) . "</td>
                        <td>" . htmlspecialchars($row['start_time']) . "</td>
                        <td>" . htmlspecialchars($row['end_time']) . "</td>
                      </tr>";
            }
            echo '</tbody></table>'; // Close the last table
        } else {
            echo "<p class='text-center'>No classes scheduled.</p>";
        }
        ?>
        
        <div class="text-center mt-4">
            <a href="?download=true" class="btn btn-success">Download Schedule as CSV</a>
            <a href="/Class-Exam-Scheduling/app/views/student/dashboard.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the connection
$conn->close();