<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Get the student's user ID
$user_id = $_SESSION['user_id'];

// Fetch sections
$sections_result = $conn->query("SELECT section_id, section_name FROM sections");

// Fetch the current section for the student
$current_section_query = "
    SELECT section_id FROM section_enrollment WHERE student_id = ?
";
$stmt = $conn->prepare($current_section_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$current_section_result = $stmt->get_result();
$current_section = $current_section_result->fetch_assoc();
$current_section_id = $current_section ? $current_section['section_id'] : null;

// Handle section enrollment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_section'])) {
        $section_id = $_POST['section_id'];
        
        // Check if already enrolled in the selected section
        if ($current_section_id !== null) {
            // Update existing section
            $stmt = $conn->prepare("UPDATE section_enrollment SET section_id = ? WHERE student_id = ?");
            $stmt->bind_param("ii", $section_id, $user_id);
            $stmt->execute();
            echo "<p class='success'>Successfully updated section.</p>";
        } else {
            // Insert new section enrollment
            $stmt = $conn->prepare("INSERT INTO section_enrollment (student_id, section_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $user_id, $section_id);
            $stmt->execute();
            echo "<p class='success'>Successfully enrolled in section.</p>";
        }
        $stmt->close();

        // Refresh the page after the update
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll Section</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Roboto', sans-serif; background-color: #f4f4f4; color: #333; }
        .container { max-width: 600px; margin: 50px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); }
        h1 { text-align: center; color: #007BFF; }
        select, button { width: 100%; padding: 10px; margin: 10px 0; }
        button { background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        .success { color: green; text-align: center; }
        .current-section { margin-top: 20px; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Section</h1>
        <form method="POST" action="">
            <label for="section_id">Select Section:</label>
            <select name="section_id" id="section_id" required>
                <?php while ($row = $sections_result->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($row['section_id']); ?>" 
                        <?php echo $current_section_id == $row['section_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($row['section_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <button type="submit" name="update_section">Update</button>
        </form>

        <div class="current-section">
            <?php if ($current_section_id): ?>
                <p>Current Section: 
                    <strong><?php 
                        // Reopen connection to fetch current section name
                        $conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");
                        $current_section_name_query = "SELECT section_name FROM sections WHERE section_id = ?";
                        $stmt = $conn->prepare($current_section_name_query);
                        $stmt->bind_param("i", $current_section_id);
                        $stmt->execute();
                        $current_section_name_result = $stmt->get_result();
                        $current_section_name = $current_section_name_result->fetch_assoc();
                        echo htmlspecialchars($current_section_name['section_name']); 
                        $stmt->close();
                        $conn->close(); // Close connection after use
                    ?></strong>
                </p>
            <?php else: ?>
                <p>No section enrolled.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>