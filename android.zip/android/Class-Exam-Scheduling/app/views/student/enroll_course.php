<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Get the student's user ID
$user_id = $_SESSION['user_id'];

// Fetch the student's department_id
$query = "SELECT department_id FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Student not found.");
}

$student = $result->fetch_assoc();
$department_id = $student['department_id'];

// Fetch available courses for the student's department
$query = "SELECT course_id, course_name FROM courses WHERE department_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $department_id);
$stmt->execute();
$courses_result = $stmt->get_result();

// Fetch enrolled courses
$query = "
    SELECT c.course_id, c.course_name 
    FROM course_enrollment ce 
    JOIN courses c ON ce.course_id = c.course_id 
    WHERE ce.student_id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$enrolled_courses_result = $stmt->get_result();

// Store enrolled course IDs in an array for easy lookup
$enrolled_courses_ids = [];
while ($row = $enrolled_courses_result->fetch_assoc()) {
    $enrolled_courses_ids[] = $row['course_id'];
}

// Handle course enrollment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['enroll_course'])) {
        $course_id = $_POST['course_id'];
        $stmt = $conn->prepare("INSERT INTO course_enrollment (student_id, course_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $course_id);
        if ($stmt->execute()) {
            echo "<p class='success'>Successfully enrolled in the course.</p>";
        } else {
            echo "<p class='error'>Error enrolling in the course.</p>";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll Course</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Roboto', sans-serif; background-color: #f4f4f4; color: #333; }
        .container { max-width: 600px; margin: 50px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); }
        h1 { text-align: center; color: #007BFF; }
        select, button { width: 100%; padding: 10px; margin: 10px 0; }
        button { background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        .success { color: green; text-align: center; }
        .enrolled-courses { margin-top: 20px; }
        .enrolled-courses h2 { text-align: center; color: #007BFF; }
        ul { list-style-type: none; padding: 0; }
        li { padding: 5px; border-bottom: 1px solid #ddd; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Enroll in Course</h1>
        <form method="POST" action="">
            <label for="course_id">Select Course:</label>
            <select name="course_id" id="course_id" required>
                <?php while ($row = $courses_result->fetch_assoc()): ?>
                    <?php if (!in_array($row['course_id'], $enrolled_courses_ids)): ?>
                        <option value="<?php echo htmlspecialchars($row['course_id']); ?>">
                            <?php echo htmlspecialchars($row['course_name']); ?>
                        </option>
                    <?php endif; ?>
                <?php endwhile; ?>
            </select>
            <button type="submit" name="enroll_course">Enroll</button>
        </form>

        <div class="enrolled-courses">
            <h2>Your Enrolled Courses</h2>
            <ul>
                <?php if ($enrolled_courses_result->num_rows > 0): ?>
                    <?php
                    // Reset the result pointer to display enrolled courses
                    $enrolled_courses_result->data_seek(0);
                    while ($row = $enrolled_courses_result->fetch_assoc()): ?>
                        <li><?php echo htmlspecialchars($row['course_name']); ?></li>
                    <?php endwhile; ?>
                <?php else: ?>
                    <li>No courses enrolled yet.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</body>
</html>