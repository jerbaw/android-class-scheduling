<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is an instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instructor') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$assigned_courses = [];

// Fetch the courses, section names, entry years, exam dates, exam times, and classrooms assigned to the instructor
$assigned_courses_query = "
    SELECT pes.course_id, s.section_name, pes.year_id, pes.exam_date, pes.exam_time, cl.room_name, c.course_name, y.year
    FROM posted_exam_schedule pes
    JOIN courses c ON pes.course_id = c.course_id
    JOIN classrooms cl ON pes.classroom_id = cl.classroom_id
    JOIN entry_year y ON pes.year_id = y.year_id
    JOIN sections s ON pes.section_id = s.section_id
    WHERE pes.course_id IN (
        SELECT course_id 
        FROM assignments 
        WHERE instructor_id = ?
    )";

$stmt = $conn->prepare($assigned_courses_query);
$stmt->bind_param("i", $instructor_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $row['exam_date'] = date("F j, Y", strtotime($row['exam_date'])); // Format date
    $row['exam_time'] = date("g:i A", strtotime($row['exam_time'])); // Format time
    $assigned_courses[$row['year']][] = $row;
}

if (isset($_POST['download_csv'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename=assigned_courses.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, array('Course Name', 'Section Name', 'Entry Year', 'Exam Date', 'Exam Time', 'Classroom'));

    foreach ($assigned_courses as $year => $courses) {
        foreach ($courses as $course) {
            fputcsv($output, array(
                $course['course_name'], 
                $course['section_name'], 
                $course['year'], 
                $course['exam_date'], 
                $course['exam_time'], 
                $course['room_name']
            ));
        }
    }
    fclose($output);
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Assigned Courses</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">
    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold mb-6 text-center">Exam Schedule</h1>

        <?php if (empty($assigned_courses)): ?>
            <div class="bg-yellow-100 text-yellow-700 p-4 rounded mb-4">
                No assigned courses found.
            </div>
        <?php else: ?>
            <form method="post">
                <button type="submit" name="download_csv" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4">
                    Download CSV
                </button>
            </form>
            <?php foreach ($assigned_courses as $year => $courses): ?>
                <div class="bg-white shadow-md rounded-lg p-4 mb-4">
                    <h2 class="text-2xl font-bold mb-4">Entry Year: <?php echo htmlspecialchars($year); ?></h2>
                    <table class="table-auto w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="px-4 py-2">Course Name</th>
                                <th class="px-4 py-2">Section Name</th>
                                <th class="px-4 py-2">Exam Date</th>
                                <th class="px-4 py-2">Exam Time</th>
                                <th class="px-4 py-2">Classroom</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($courses as $course): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($course['course_name']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($course['section_name']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($course['exam_date']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($course['exam_time']); ?></td>
                                    <td class="px-4 py-2"><?php echo htmlspecialchars($course['room_name']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
