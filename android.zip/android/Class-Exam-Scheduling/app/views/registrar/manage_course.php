<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// // Assuming you have a session with user_id available
// session_start();
// $user_id = $_SESSION['user_id']; // Replace this with your actual session management

// Handle form submissions for adding, updating, and deleting
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add'])) {
        $course_name = $_POST['course_name'];
        $department_id = $_POST['department_id'];
        $stmt = $conn->prepare("INSERT INTO courses (course_name, department_id, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("si", $course_name, $department_id);
        $stmt->execute();
        
        // Log activity
        $activity = "Added course: " . $course_name;
        $stmt = $conn->prepare("INSERT INTO useractivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $activity);
        $stmt->execute();
        $stmt->close();
    }

    if (isset($_POST['update'])) {
        $course_id = $_POST['course_id'];
        $course_name = $_POST['course_name'];
        $department_id = $_POST['department_id'];

        // Fetch current course name before update
        $stmt = $conn->prepare("SELECT course_name FROM courses WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $current_course_name = $result->fetch_assoc()['course_name'];
        $stmt->close();

        $stmt = $conn->prepare("UPDATE courses SET course_name = ?, department_id = ?, created_at = NOW() WHERE course_id = ?");
        $stmt->bind_param("sii", $course_name, $department_id, $course_id);
        $stmt->execute();

        // Log activity
        $activity = "Updated course: " . $current_course_name . " to " . $course_name;
        $stmt = $conn->prepare("INSERT INTO useractivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $activity);
        $stmt->execute();
        $stmt->close();
    }

    if (isset($_POST['delete'])) {
        $course_id = $_POST['course_id'];

        // Fetch course name before deletion
        $stmt = $conn->prepare("SELECT course_name FROM courses WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $course_name = $result->fetch_assoc()['course_name'];
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM courses WHERE course_id = ?");
        $stmt->bind_param("i", $course_id);
        $stmt->execute();

        // Log activity
        $activity = "Deleted course: " . $course_name;
        $stmt = $conn->prepare("INSERT INTO useractivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $activity);
        $stmt->execute();
        $stmt->close();
    }
}

// Fetch courses
$courses_result = $conn->query("SELECT courses.*, departments.department_name FROM courses JOIN departments ON courses.department_id = departments.department_id");

// Fetch departments for course assignment
$departments_result = $conn->query("SELECT * FROM departments");

if (!$departments_result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { 
            background-color: #f8f9fa; 
        }
        .container { 
            margin-top: 20px; 
        }
        .table th, .table td { 
            vertical-align: middle; 
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Manage Courses</h1>

    <!-- Form to add a new course -->
    <form method="POST" class="mb-4">
        <div class="form-row">
            <div class="col">
                <input type="text" class="form-control" name="course_name" placeholder="Course Name" required>
            </div>
            <div class="col">
                <select name="department_id" class="form-control" required>
                    <option value="">Select Department</option>
                    <?php while ($department = $departments_result->fetch_assoc()): ?>
                        <option value="<?php echo $department['department_id']; ?>"><?php echo $department['department_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col">
                <button type="submit" name="add" class="btn btn-primary">Add Course</button>
            </div>
        </div>
    </form>

    <!-- Table to display courses -->
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Course Name</th>
                <th>Department</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($course = $courses_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $course['course_id']; ?></td>
                <td><?php echo $course['course_name']; ?></td>
                <td><?php echo $course['department_name']; ?></td>
                <td>
                    <!-- Update button triggers modal -->
                    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModal<?php echo $course['course_id']; ?>">
                        Edit
                    </button>
                    <!-- Delete form -->
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="course_id" value="<?php echo $course['course_id']; ?>">
                        <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this course?');">Delete</button>
                    </form>
                </td>
            </tr>

            <!-- Edit Modal -->
            <div class="modal fade" id="editModal<?php echo $course['course_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Edit Course</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <input type="hidden" name="course_id" value="<?php echo $course['course_id']; ?>">
                                <div class="form-group">
                                    <label for="course_name">Course Name</label>
                                    <input type="text" class="form-control" name="course_name" value="<?php echo $course['course_name']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="department_id">Department</label>
                                    <select name="department_id" class="form-control" required>
                                        <option value="">Select Department</option>
                                        <?php
                                        // Reset department result for department selection
                                        $departments_result->data_seek(0);
                                        while ($department = $departments_result->fetch_assoc()): ?>
                                            <option value="<?php echo $department['department_id']; ?>" <?php echo ($department['department_id'] == $course['department_id']) ? 'selected' : ''; ?>><?php echo $department['department_name']; ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" name="update" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>