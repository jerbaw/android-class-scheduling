<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// // Assuming you have a session with user_id available
// session_start();
// $user_id = $_SESSION['user_id']; // Replace this with your actual session management

// Handle form submissions for adding, updating, and deleting
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add'])) {
        $room_name = $_POST['room_name'];
        $capacity = $_POST['capacity'];
        $stmt = $conn->prepare("INSERT INTO classrooms (room_name, capacity, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("si", $room_name, $capacity);
        $stmt->execute();
        
        // Log activity
        $activity = "Added classroom: " . $room_name;
        $stmt = $conn->prepare("INSERT INTO useractivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $activity);
        $stmt->execute();
        $stmt->close();
    }

    if (isset($_POST['update'])) {
        $classroom_id = $_POST['classroom_id'];
        $room_name = $_POST['room_name'];
        $capacity = $_POST['capacity'];

        // Fetch current room name before update
        $stmt = $conn->prepare("SELECT room_name FROM classrooms WHERE classroom_id = ?");
        $stmt->bind_param("i", $classroom_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $current_room_name = $result->fetch_assoc()['room_name'];
        $stmt->close();

        $stmt = $conn->prepare("UPDATE classrooms SET room_name = ?, capacity = ?, created_at = NOW() WHERE classroom_id = ?");
        $stmt->bind_param("sii", $room_name, $capacity, $classroom_id);
        $stmt->execute();

        // Log activity
        $activity = "Updated classroom: " . $current_room_name . " to " . $room_name;
        $stmt = $conn->prepare("INSERT INTO useractivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $activity);
        $stmt->execute();
        $stmt->close();
    }

    if (isset($_POST['delete'])) {
        $classroom_id = $_POST['classroom_id'];

        // Fetch room name before deletion
        $stmt = $conn->prepare("SELECT room_name FROM classrooms WHERE classroom_id = ?");
        $stmt->bind_param("i", $classroom_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $room_name = $result->fetch_assoc()['room_name'];
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM classrooms WHERE classroom_id = ?");
        $stmt->bind_param("i", $classroom_id);
        $stmt->execute();

        // Log activity
        $activity = "Deleted classroom: " . $room_name;
        $stmt = $conn->prepare("INSERT INTO useractivities (user_id, activity) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $activity);
        $stmt->execute();
        $stmt->close();
    }
}

// Fetch classrooms
$classrooms_result = $conn->query("SELECT * FROM classrooms");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Classrooms</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { 
            background-color: #f8f9fa; 
        }
        .container { 
            margin-top: 20px; 
        }
        .table th, .table td { 
            vertical-align: middle; 
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Manage Classrooms</h1>

    <!-- Form to add a new classroom -->
    <form method="POST" class="mb-4">
        <div class="form-row">
            <div class="col">
                <input type="text" class="form-control" name="room_name" placeholder="Room Name" required>
            </div>
            <div class="col">
                <input type="number" class="form-control" name="capacity" placeholder="Capacity" required>
            </div>
            <div class="col">
                <button type="submit" name="add" class="btn btn-primary">Add Classroom</button>
            </div>
        </div>
    </form>

    <!-- Table to display classrooms -->
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Room Name</th>
                <th>Capacity</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($classroom = $classrooms_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $classroom['classroom_id']; ?></td>
                <td><?php echo $classroom['room_name']; ?></td>
                <td><?php echo $classroom['capacity']; ?></td>
                <td>
                    <!-- Update button triggers modal -->
                    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModal<?php echo $classroom['classroom_id']; ?>">
                        Edit
                    </button>
                    <!-- Delete form -->
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="classroom_id" value="<?php echo $classroom['classroom_id']; ?>">
                        <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this classroom?');">Delete</button>
                    </form>
                </td>
            </tr>

            <!-- Edit Modal -->
            <div class="modal fade" id="editModal<?php echo $classroom['classroom_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Edit Classroom</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <input type="hidden" name="classroom_id" value="<?php echo $classroom['classroom_id']; ?>">
                                <div class="form-group">
                                    <label for="room_name">Room Name</label>
                                    <input type="text" class="form-control" name="room_name" value="<?php echo $classroom['room_name']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="capacity">Capacity</label>
                                    <input type="number" class="form-control" name="capacity" value="<?php echo $classroom['capacity']; ?>" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" name="update" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>