<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize message variable
$message = '';

// Handle form submission to add a new or update an exam
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        $course_id = $_POST['course_id'];
        $exam_date = $_POST['exam_date'];
        $exam_time = $_POST['exam_time'];
        $classroom_id = $_POST['classroom_id'];
        $section_id = $_POST['section_id'];
        $year_id = $_POST['year_id'];

        // Validate inputs
        if (empty($course_id) || empty($exam_date) || empty($exam_time) || empty($classroom_id) || empty($section_id) || empty($year_id)) {
            $message = 'All fields are required.';
        } else {
            // Convert exam time to 24-hour format for database storage
            $exam_time_24hr = date("H:i", strtotime($exam_time));

            if ($action === 'add') {
                // Insert exam into the database
                $stmt = $conn->prepare("INSERT INTO exam_schedule (course_id, exam_date, exam_time, classroom_id, section_id, year_id) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("issiii", $course_id, $exam_date, $exam_time_24hr, $classroom_id, $section_id, $year_id);
                $stmt->execute();
                $message = 'Exam scheduled successfully.';
            } elseif ($action === 'update') {
                $exam_id = $_POST['exam_id'];
                // Update exam in the database
                $stmt = $conn->prepare("UPDATE exam_schedule SET course_id = ?, exam_date = ?, exam_time = ?, classroom_id = ?, section_id = ?, year_id = ? WHERE id = ?");
                $stmt->bind_param("issiiii", $course_id, $exam_date, $exam_time_24hr, $classroom_id, $section_id, $year_id, $exam_id);
                $stmt->execute();
                $message = 'Exam updated successfully.';
            }
        }
    }
    // Post schedule (copy from exam_schedule to posted_exam_schedule)
    if (isset($_POST['post_schedule'])) {
        // Clear the posted_exam_schedule table
        $conn->query("DELETE FROM posted_exam_schedule");

        // Copy data from exam_schedule to posted_exam_schedule
        $copy_query = "INSERT INTO posted_exam_schedule (course_id, exam_date, exam_time, classroom_id, section_id, year_id)
                       SELECT course_id, exam_date, exam_time, classroom_id, section_id, year_id
                       FROM exam_schedule";
        if ($conn->query($copy_query) === TRUE) {
            $message = "Exam schedule posted successfully.";
        } else {
            $message = "Error posting exam schedule: " . $conn->error;
        }
    }

    // Clear posted exam schedule
    if (isset($_POST['clear_post'])) {
        $conn->query("DELETE FROM posted_exam_schedule");
        $message = "Posted exam schedule cleared successfully.";
    }
}

// Handle delete request
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $exam_id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM exam_schedule WHERE id = ?");
    $stmt->bind_param("i", $exam_id);
    $stmt->execute();
    header("Location: exam_schedule.php");
    exit;
}

// Fetch existing exams from the database based on selected year
$selected_year_id = isset($_GET['year_id']) ? $_GET['year_id'] : null;

$query = "
    SELECT es.*, c.course_name, cl.room_name, s.section_name, y.year
    FROM exam_schedule es
    JOIN courses c ON es.course_id = c.course_id
    JOIN classrooms cl ON es.classroom_id = cl.classroom_id
    JOIN sections s ON es.section_id = s.section_id
    JOIN entry_year y ON es.year_id = y.year_id";

if ($selected_year_id) {
    $query .= " WHERE es.year_id = " . intval($selected_year_id);
}

$query .= " ORDER BY y.year, es.exam_date, es.exam_time";
$result = $conn->query($query);

// Organize exams by year
$exams_by_year = [];
while ($row = $result->fetch_assoc()) {
    // Convert exam_time to 12-hour format for display
    $row['exam_time'] = date("g:i A", strtotime($row['exam_time']));
    $exams_by_year[$row['year']][] = $row;
}

// Fetch dropdown data
$courses = $conn->query("SELECT course_id, course_name FROM courses");
$classrooms = $conn->query("SELECT classroom_id, room_name FROM classrooms");
$sections = $conn->query("SELECT section_id, section_name FROM sections");
$years = $conn->query("SELECT year_id, year FROM entry_year");

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Schedule</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f7fa;
            color: #333;
        }
                header {
            background-color: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: x-large;
        }
        .modal { display: none; }
        .modal.active { display: flex; }
        .btn-post {
            border: 2px solid transparent;
            border-radius: 25px;
            background-color: white;
            color: black;
            padding: 10px 20px;
            transition: border-color 0.3s, background-color 0.3s, color 0.3s;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .btn-post:hover {
            border-color: #333;
            background-color: #f8f9fa;
            color: #007bff;
        }
    </style>
</head>

<body class="bg-gray-100 text-gray-800">
<header>
    <h1>Exam Scheduling System</h1>
</header>
    <div class="container mx-auto p-6">


        <!-- Display Message -->
        <?php if ($message): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded mb-4">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Year Filter -->
        <div class="mb-6">
            <form method="GET" class="flex justify-between items-center">
                
                <select id="year_id" name="year_id" class="p-2 border rounded" onchange="this.form.submit()">
                    <option value="">Select Year</option>
                    <?php foreach ($years as $year): ?>
                        <option value="<?php echo $year['year_id']; ?>" <?php echo ($year['year_id'] == $selected_year_id) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($year['year']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <!-- Add/Edit Exam Button and Post Schedule Button -->
        <div class="flex justify-between items-center mb-6">
            <button id="openModal" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                + Schedule New Exam
            </button>
            <form method="POST" class="ml-4" onsubmit="return confirmPost()">
                <input type="hidden" name="post_schedule" value="1">
                <button type="submit" class="btn btn-post">
                    <i class="fas fa-paper-plane"></i> Post Exam Schedule
                </button>
            </form>
            <form method="POST" class="ml-4" onsubmit="return confirmClear()">
            <input type="hidden" name="clear_post" value="1">
            <button type="submit" class="btn btn-danger">
                <i class="fas fa-trash"></i> Clear Posted Schedule
            </button>
        </form>
        </div>

        <!-- Exams Table -->
        <div class="bg-white shadow-md rounded-lg p-4">
            <?php foreach ($exams_by_year as $year => $exams): ?>
                <h2 class="text-xl font-semibold mb-4 border-b pb-2"><?php echo htmlspecialchars($year); ?></h2>
                <table class="table-auto w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-200">
                            <th class="px-4 py-2">Course Name</th>
                            <th class="px-4 py-2">Exam Date</th>
                            <th class="px-4 py-2">Exam Time</th>
                            <th class="px-4 py-2">Classroom</th>
                            <th class="px-4 py-2">Section</th>
                            <th class="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($exams as $exam): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2"><?php echo htmlspecialchars($exam['course_name']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($exam['exam_date']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($exam['exam_time']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($exam['room_name']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($exam['section_name']); ?></td>
                                <td class="px-4 py-2">
                                    <button onclick="editExam(<?php echo htmlspecialchars(json_encode($exam)); ?>)" class="text-blue-500 hover:underline">Edit</button>
                                    <button onclick="confirmDelete(<?php echo $exam['id']; ?>)" class="text-red-500 hover:underline">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Modal -->
    <div id="modal" class="modal fixed inset-0 bg-gray-800 bg-opacity-50 items-center justify-center">
        <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-lg">
            <h2 id="modalTitle" class="text-xl font-bold mb-4">Schedule Exam</h2>
            <form id="examForm" method="POST" action="">
                <input type="hidden" name="action" value="add">
                <input type="hidden" id="exam_id" name="exam_id">

                <label for="course_id" class="block mb-2">Course:</label>
                <select id="course_id" name="course_id" class="w-full mb-4 p-2 border rounded" required>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?php echo $course['course_id']; ?>"><?php echo htmlspecialchars($course['course_name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="exam_date" class="block mb-2">Exam Date:</label>
                <input type="date" id="exam_date" name="exam_date" class="w-full mb-4 p-2 border rounded" required>

                <label for="exam_time" class="block mb-2">Exam Time:</label>
                <input type="time" id="exam_time" name="exam_time" class="w-full mb-4 p-2 border rounded" required>

                <label for="classroom_id" class="block mb-2">Classroom:</label>
                <select id="classroom_id" name="classroom_id" class="w-full mb-4 p-2 border rounded" required>
                    <?php foreach ($classrooms as $classroom): ?>
                        <option value="<?php echo $classroom['classroom_id']; ?>"><?php echo htmlspecialchars($classroom['room_name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="section_id" class="block mb-2">Section:</label>
                <select id="section_id" name="section_id" class="w-full mb-4 p-2 border rounded" required>
                    <?php foreach ($sections as $section): ?>
                        <option value="<?php echo $section['section_id']; ?>"><?php echo htmlspecialchars($section['section_name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="year_id" class="block mb-2">Year:</label>
                <select id="year_id" name="year_id" class="w-full mb-6 p-2 border rounded" required>
                    <?php foreach ($years as $year): ?>
                        <option value="<?php echo $year['year_id']; ?>"><?php echo htmlspecialchars($year['year']); ?></option>
                    <?php endforeach; ?>
                </select>

                <div class="flex justify-end gap-4">
                    <button type="button" id="closeModal" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Cancel</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Submit</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('modal');
        const openModal = document.getElementById('openModal');
        const closeModal = document.getElementById('closeModal');
        const modalTitle = document.getElementById('modalTitle');
        const examForm = document.getElementById('examForm');

        openModal.addEventListener('click', () => {
            modal.classList.add('active');
            modalTitle.textContent = 'Schedule Exam';
            examForm.action.value = 'add';
            examForm.reset();
        });

        closeModal.addEventListener('click', () => {
            modal.classList.remove('active');
        });

        function confirmPost() {
            return confirm('Are you sure you want to post the exam schedule?');
        }

        function editExam(exam) {
            modal.classList.add('active');
            modalTitle.textContent = 'Edit Exam';
            examForm.action.value = 'update';
            examForm.exam_id.value = exam.id;
            examForm.course_id.value = exam.course_id;
            examForm.exam_date.value = exam.exam_date;
            examForm.exam_time.value = exam.exam_time;
            examForm.classroom_id.value = exam.classroom_id;
            examForm.section_id.value = exam.section_id;
            examForm.year_id.value = exam.year_id;
        }
        function confirmClear() {
        return confirm('Are you sure you want to clear the posted exam schedule?');
    }
        function confirmDelete(id) {
            if (confirm('Are you sure you want to delete this exam?')) {
                window.location.href = `?action=delete&id=${id}`;
            }
        }
    </script>

</body>
</html>