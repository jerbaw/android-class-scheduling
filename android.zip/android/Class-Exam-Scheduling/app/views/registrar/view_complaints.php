<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update'])) {
        $complaint_id = $_POST['complaint_id'];
        $status = $_POST['status'];

        // Prepare and execute the update statement
        $stmt = $conn->prepare("UPDATE complaints SET status = ? WHERE complaint_id = ?");
        $stmt->bind_param("si", $status, $complaint_id);
        $stmt->execute();
        $stmt->close();
    }
}

// Fetch complaints
$complaints_result = $conn->query("SELECT c.complaint_id, c.description, c.status, c.created_at, u.full_name 
                                    FROM complaints c 
                                    JOIN users u ON c.user_id = u.id");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Complaints</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { 
            background-color: #f8f9fa; 
        }
        .container { 
            margin-top: 20px; 
        }
        .table th, .table td { 
            vertical-align: middle; 
        }
        .status-pending { color: orange; }
        .status-resolved { color: green; }
        .status-rejected { color: red; }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">View Complaints</h1>

    <!-- Table to display complaints -->
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Complaint ID</th>
                <th>User</th>
                <th>Description</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($complaint = $complaints_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $complaint['complaint_id']; ?></td>
                <td><?php echo $complaint['full_name']; ?></td>
                <td><?php echo $complaint['description']; ?></td>
                <td class="<?php echo 'status-' . strtolower($complaint['status']); ?>">
                    <?php echo $complaint['status']; ?>
                </td>
                <td><?php echo $complaint['created_at']; ?></td>
                <td>
                    <!-- Update button triggers modal -->
                    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#updateModal<?php echo $complaint['complaint_id']; ?>">
                        Update Status
                    </button>
                </td>
            </tr>

            <!-- Update Status Modal -->
            <div class="modal fade" id="updateModal<?php echo $complaint['complaint_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="updateModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="updateModalLabel">Update Complaint Status</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <input type="hidden" name="complaint_id" value="<?php echo $complaint['complaint_id']; ?>">
                                <div class="form-group">
                                    <label for="status">Status</label>
                                    <select name="status" class="form-control" required>
                                        <option value="Pending" <?php echo ($complaint['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                        <option value="Resolved" <?php echo ($complaint['status'] == 'Resolved') ? 'selected' : ''; ?>>Resolved</option>
                                        <option value="Rejected" <?php echo ($complaint['status'] == 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" name="update" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>