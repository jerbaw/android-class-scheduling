<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data for dropdowns
function fetchOptions($conn, $table, $id_column, $name_column, $condition = '') {
    $options = [];
    $query = "SELECT $id_column, $name_column FROM $table";
    if (!empty($condition)) {
        $query .= " WHERE $condition";
    }
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $options[] = $row;
    }
    return $options;
}

$classrooms = fetchOptions($conn, 'classrooms', 'classroom_id', 'room_name');
$courses = fetchOptions($conn, 'courses', 'course_id', 'course_name');
$sections = fetchOptions($conn, 'sections', 'section_id', 'section_name');
$instructors = fetchOptions($conn, 'users', 'id', 'full_name', "role = 'instructor'");
$entry_years = fetchOptions($conn, 'entry_year', 'year_id', 'year');

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add a new schedule
    if (isset($_POST['add_schedule'])) {
        $course_id = $_POST['course_id'];
        $section_id = $_POST['section_id'];
        $instructor_id = $_POST['instructor_id'];
        $classroom_id = $_POST['classroom_id'];
        $entry_year_id = $_POST['entry_year'];
        $day_of_week = $_POST['day_of_week'];
        $start_time = $_POST['start_time'];
        $end_time = $_POST['end_time'];

        // Fetch the actual year value from the `entry_year` table
        $year_result = $conn->query("SELECT year FROM entry_year WHERE year_id = $entry_year_id");
        $entry_year_row = $year_result->fetch_assoc();
        $entry_year = $entry_year_row['year'];

        // Insert the data into the `class_schedule` table
        $stmt = $conn->prepare(
            "INSERT INTO class_schedule (course_id, section_id, instructor_id, classroom_id, entry_year, day_of_week, start_time, end_time, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())"
        );
        $stmt->bind_param(
            'iiiiisss',
            $course_id,
            $section_id,
            $instructor_id,
            $classroom_id,
            $entry_year,
            $day_of_week,
            $start_time,
            $end_time
        );
        $stmt->execute();
        $stmt->close();
    }

    // Edit an existing schedule
    if (isset($_POST['edit_schedule'])) {
        $schedule_id = $_POST['schedule_id'];
        $course_id = $_POST['course_id'];
        $section_id = $_POST['section_id'];
        $instructor_id = $_POST['instructor_id'];
        $classroom_id = $_POST['classroom_id'];
        $entry_year_id = $_POST['entry_year'];
        $day_of_week = $_POST['day_of_week'];
        $start_time = $_POST['start_time'];
        $end_time = $_POST['end_time'];

        // Fetch the actual year value
        $year_result = $conn->query("SELECT year FROM entry_year WHERE year_id = $entry_year_id");
        $entry_year_row = $year_result->fetch_assoc();
        $entry_year = $entry_year_row['year'];

        // Update the schedule
        $stmt = $conn->prepare(
            "UPDATE class_schedule 
            SET course_id = ?, section_id = ?, instructor_id = ?, classroom_id = ?, entry_year = ?, day_of_week = ?, start_time = ?, end_time = ? 
            WHERE schedule_id = ?"
        );
        $stmt->bind_param(
            'iiiiisssi',
            $course_id,
            $section_id,
            $instructor_id,
            $classroom_id,
            $entry_year,
            $day_of_week,
            $start_time,
            $end_time,
            $schedule_id
        );
        $stmt->execute();
        $stmt->close();
    }
}

// Handle deletion
if (isset($_GET['delete_schedule'])) {
    $schedule_id = $_GET['delete_schedule'];
    $conn->query("DELETE FROM class_schedule WHERE schedule_id = $schedule_id");
}

// Handle search
$search_query = '';
if (isset($_GET['search'])) {
    $search_term = $conn->real_escape_string($_GET['search']);
    $search_query = " WHERE c.course_name LIKE '%$search_term%' OR s.section_name LIKE '%$search_term%' OR u.full_name LIKE '%$search_term%' OR cr.room_name LIKE '%$search_term%'";
}

// Fetch class schedules for display
$schedules = $conn->query("
    SELECT 
        cs.schedule_id,
        c.course_id,
        c.course_name,
        s.section_id,
        s.section_name,
        u.id AS instructor_id,
        u.full_name AS instructor_name,
        cr.classroom_id,
        cr.room_name,
        cs.entry_year,
        cs.day_of_week,
        cs.start_time,
        cs.end_time
    FROM class_schedule cs
    INNER JOIN courses c ON cs.course_id = c.course_id
    INNER JOIN sections s ON cs.section_id = s.section_id
    INNER JOIN users u ON cs.instructor_id = u.id
    INNER JOIN classrooms cr ON cs.classroom_id = cr.classroom_id
    $search_query
    ORDER BY cs.day_of_week, cs.start_time
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Schedule</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
            line-height: 1.6;
        }
        header {
            background:  #007bff;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        h1, h2 {
            margin: 0;
        }
        h2 {
            margin-top: 20px;
            color:  #007bff;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        select, input[type="time"], input[type="text"], button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: border-color 0.3s;
        }
        select:focus, input[type="time"]:focus, input[type="text"]:focus {
            border-color: #007bff;
            outline: none;
        }
        button {
            background: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background:  #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background-color:  #007bff;
            color: #fff;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .delete {
            color: #d9534f;
            text-decoration: none;
        }
        .delete:hover {
            text-decoration: underline;
        }
        .horizontal-form {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            flex: 1 1 30%; /* Adjusts the size of each field */
            margin-right: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-group select,
        .form-group input[type="time"],
        .form-group button {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: border-color 0.3s;
        }

        .form-group select:focus,
        .form-group input[type="time"]:focus {
            border-color: #007bff;
            outline: none;
        }

        .form-group button {
            background:  #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        .form-group button:hover {
            background: #45a049;
        }

        @media (max-width: 600px) {
            .form-group {
                flex: 1 1 100%; 
                margin-right: 0;
            }
            h1 {
                font-size: 24px;
            }
            button, select, input[type="time"] {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Class Schedule</h1>
    </header>
    <div class="text-center" style="margin-top: 20px;">
    <a href="generate_schedule.php" class="btn btn-primary">
        <i class="fas fa-arrow-alt-circle-right"></i> Generate Automatic Schedule
    </a>
</div>
    <!-- Add Schedule Form -->
    <h2>Add New Schedule</h2>
    <form method="post" class="horizontal-form">
        
        <input type="hidden" name="add_schedule" value="1">
        
        <div class="form-group">
            <label for="course_id">Course:</label>
            <select name="course_id" id="course_id" required>
                <option value="">-- Select Course --</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?= $course['course_id'] ?>"><?= $course['course_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="section_id">Section:</label>
            <select name="section_id" id="section_id" required>
                <option value="">-- Select Section --</option>
                <?php foreach ($sections as $section): ?>
                    <option value="<?= $section['section_id'] ?>"><?= $section['section_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="instructor_id">Instructor:</label>
            <select name="instructor_id" id="instructor_id" required>
                <option value="">-- Select Instructor --</option>
                <?php foreach ($instructors as $instructor): ?>
                    <option value="<?= $instructor['id'] ?>"><?= $instructor['full_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="classroom_id">Classroom:</label>
            <select name="classroom_id" id="classroom_id" required>
                <option value="">-- Select Classroom --</option>
                <?php foreach ($classrooms as $classroom): ?>
                    <option value="<?= $classroom['classroom_id'] ?>"><?= $classroom['room_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="entry_year">Entry Year:</label>
            <select name="entry_year" id="entry_year" required>
                <option value="">-- Select Year --</option>
                <?php foreach ($entry_years as $year): ?>
                    <option value="<?= $year['year_id'] ?>"><?= $year['year'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="day_of_week">Day:</label>
            <select name="day_of_week" id="day_of_week" required>
                <option value="">-- Select Day --</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
                <option value="Saturday">Saturday</option>
                <option value="Sunday">Sunday</option>
            </select>
        </div>

        <div class="form-group">
            <label for="start_time">Start Time:</label>
            <input type="time" name="start_time" id="start_time" required>
        </div>

        <div class="form-group">
            <label for="end_time">End Time:</label>
            <input type="time" name="end_time" id="end_time" required>
        </div>

            <button type="submit">Add Schedule</button>

    </form>

    <!-- Search Form -->
    <form method="get" action="">
        <label for="search">Search:</label>
        <input type="text" name="search" id="search" placeholder="Enter course, section, instructor, or classroom">
        <button type="submit">Search</button>
    </form>

    <!-- Display Class Schedule -->
    <h2>Current Class Schedules</h2>
    <table>
        <thead>
            <tr>
                <th>Course</th>
                <th>Section</th>
                <th>Instructor</th>
                <th>Classroom</th>
                <th>Entry Year</th>
                <th>Day</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($schedule = $schedules->fetch_assoc()): ?>
                <tr>
                    <form method="post">
                        <td>
                            <select name="course_id" required>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?= $course['course_id'] ?>" <?= $course['course_id'] == $schedule['course_id'] ? 'selected' : '' ?>>
                                        <?= $course['course_name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="section_id" required>
                                <?php foreach ($sections as $section): ?>
                                    <option value="<?= $section['section_id'] ?>" <?= $section['section_id'] == $schedule['section_id'] ? 'selected' : '' ?>>
                                        <?= $section['section_name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="instructor_id" required>
                                <?php foreach ($instructors as $instructor): ?>
                                    <option value="<?= $instructor['id'] ?>" <?= $instructor['id'] == $schedule['instructor_id'] ? 'selected' : '' ?>>
                                        <?= $instructor['full_name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="classroom_id" required>
                                <?php foreach ($classrooms as $classroom): ?>
                                    <option value="<?= $classroom['classroom_id'] ?>" <?= $classroom['classroom_id'] == $schedule['classroom_id'] ? 'selected' : '' ?>>
                                        <?= $classroom['room_name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="entry_year" required>
                                <?php foreach ($entry_years as $year): ?>
                                    <option value="<?= $year['year_id'] ?>" <?= $year['year'] == $schedule['entry_year'] ? 'selected' : '' ?>>
                                        <?= $year['year'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="day_of_week" required>
                                <option value="Monday" <?= $schedule['day_of_week'] == 'Monday' ? 'selected' : '' ?>>Monday</option>
                                <option value="Tuesday" <?= $schedule['day_of_week'] == 'Tuesday' ? 'selected' : '' ?>>Tuesday</option>
                                <option value="Wednesday" <?= $schedule['day_of_week'] == 'Wednesday' ? 'selected' : '' ?>>Wednesday</option>
                                <option value="Thursday" <?= $schedule['day_of_week'] == 'Thursday' ? 'selected' : '' ?>>Thursday</option>
                                <option value="Friday" <?= $schedule['day_of_week'] == 'Friday' ? 'selected' : '' ?>>Friday</option>
                                <option value="Saturday" <?= $schedule['day_of_week'] == 'Saturday' ? 'selected' : '' ?>>Saturday</option>
                                <option value="Sunday" <?= $schedule['day_of_week'] == 'Sunday' ? 'selected' : '' ?>>Sunday</option>
                            </select>
                        </td>
                        <td>
                            <input type="time" name="start_time" value="<?= $schedule['start_time'] ?>" required>
                        </td>
                        <td>
                            <input type="time" name="end_time" value="<?= $schedule['end_time'] ?>" required>
                        </td>
                        <td class="action-buttons">
                            <input type="hidden" name="edit_schedule" value="1">
                            <input type="hidden" name="schedule_id" value="<?= $schedule['schedule_id'] ?>">
                            <button type="submit">Save</button>
                            <a href="?delete_schedule=<?= $schedule['schedule_id'] ?>" class="delete" onclick="return confirm('Are you sure you want to delete this schedule?');">Delete</a>
                        </td>
                    </form>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>