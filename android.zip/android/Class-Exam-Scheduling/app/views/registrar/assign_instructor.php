<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
// Database connection
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for assigning an instructor
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['assign'])) {
    $course_id = $_POST['course_id'];
    $section_id = $_POST['section_id'];
    $instructor_id = $_POST['instructor_id'];
    $entry_year = $_POST['entry_year'];

    // Check if the assignment already exists for the specific entry year
    $stmt = $conn->prepare("SELECT * FROM assignments WHERE course_id = ? AND section_id = ? AND entry_year = ?");
    $stmt->bind_param("iis", $course_id, $section_id, $entry_year);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error_message = "This instructor is already assigned to this course and section for the entry year $entry_year.";
    } else {
        // Insert new assignment
        $stmt = $conn->prepare("INSERT INTO assignments (course_id, section_id, instructor_id, entry_year, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("iiis", $course_id, $section_id, $instructor_id, $entry_year);
        $stmt->execute();
        $stmt->close();
        $success_message = "Instructor assigned successfully!";
    }
}

// Handle update logic
if (isset($_GET['edit'])) {
    $assignment_id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM assignments WHERE assignment_id = ?");
    $stmt->bind_param("i", $assignment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $assignment = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $assignment_id = $_POST['assignment_id'];
    $course_id = $_POST['course_id'];
    $section_id = $_POST['section_id'];
    $instructor_id = $_POST['instructor_id'];
    $entry_year = $_POST['entry_year'];

    // Update assignment
    $stmt = $conn->prepare("UPDATE assignments SET course_id = ?, section_id = ?, instructor_id = ?, entry_year = ? WHERE assignment_id = ?");
    $stmt->bind_param("iisii", $course_id, $section_id, $instructor_id, $entry_year, $assignment_id);
    $stmt->execute();
    $stmt->close();
    $success_message = "Assignment updated successfully!";
}

// Handle delete logic
if (isset($_GET['delete'])) {
    $assignment_id = $_GET['delete'];

    // Prepare and execute delete statement
    $stmt = $conn->prepare("DELETE FROM assignments WHERE assignment_id = ?");
    $stmt->bind_param("i", $assignment_id);
    if ($stmt->execute()) {
        $success_message = "<div class='alert alert-danger'>Assignment deleted successfully!</div>";
    } else {
        $error_message = "Error deleting assignment: " . $conn->error;
    }
    $stmt->close();
}

// Fetch courses for the dropdown
$courses_result = $conn->query("SELECT * FROM courses");

// Fetch sections for the dropdown
$sections_result = $conn->query("SELECT * FROM sections");

// Fetch instructors for the dropdown
$instructors_result = $conn->query("SELECT id, full_name FROM users WHERE role = 'instructor'");

// Fetch entry years for the dropdown
$entry_years_result = $conn->query("SELECT year FROM entry_year");

// Fetch unique entry years from assignments
$entry_years = [];
$entry_year_result = $conn->query("SELECT DISTINCT entry_year FROM assignments");
while ($year = $entry_year_result->fetch_assoc()) {
    $entry_years[] = $year['entry_year'];
}

// Handle filtering by entry year and section
$selected_year = isset($_GET['filter_year']) ? $_GET['filter_year'] : null;
$selected_section = isset($_GET['filter_section']) ? $_GET['filter_section'] : null;

// Fetch assignments grouped by entry year based on filter
$assignments_by_year = [];
foreach ($entry_years as $year) {
    // Prepare the SQL query with a conditional filter for the selected year and section
    $query = "SELECT a.assignment_id, c.course_name, s.section_name, u.full_name AS instructor_name, a.entry_year, a.created_at 
              FROM assignments a 
              JOIN courses c ON a.course_id = c.course_id 
              JOIN sections s ON a.section_id = s.section_id 
              JOIN users u ON a.instructor_id = u.id 
              WHERE a.entry_year = ?";
    
    // Add filters for the selected year and section if they are set
    if ($selected_year) {
        $query .= " AND a.entry_year = ?";
    }
    if ($selected_section) {
        $query .= " AND a.section_id = ?";
    }

    // Prepare the statement
    $stmt = $conn->prepare($query);

    // Bind parameters based on whether a selected year and section are provided
    if ($selected_year && $selected_section) {
        $stmt->bind_param("ssi", $year, $selected_year, $selected_section);
    } elseif ($selected_year) {
        $stmt->bind_param("ss", $year, $selected_year);
    } elseif ($selected_section) {
        $stmt->bind_param("si", $year, $selected_section);
    } else {
        $stmt->bind_param("s", $year);
    }

    // Execute the statement
    $stmt->execute();
    $result = $stmt->get_result();

    // Store the results in the assignments_by_year array
    $assignments_by_year[$year] = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Instructor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { 
            background-color: #f8f9fa; 
        }
        .container { 
            margin-top: 20px; 
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Assign Instructor to Course and Section</h1>

    <?php if (isset($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>

    <!-- Form to assign an instructor -->
    <form method="POST" class="mb-4">
        <div class="form-row">
            <div class="col">
                <select name="course_id" class="form-control" required>
                    <option value="">Select Course</option>
                    <?php while ($course = $courses_result->fetch_assoc()): ?>
                        <option value="<?php echo $course['course_id']; ?>" <?php echo (isset($assignment) && $assignment['course_id'] == $course['course_id']) ? 'selected' : ''; ?>><?php echo $course['course_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col">
                <select name="section_id" class="form-control" required>
                    <option value="">Select Section</option>
                    <?php while ($section = $sections_result->fetch_assoc()): ?>
                        <option value="<?php echo $section['section_id']; ?>" <?php echo (isset($assignment) && $assignment['section_id'] == $section['section_id']) ? 'selected' : ''; ?>><?php echo $section['section_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col">
                <select name="instructor_id" class="form-control" required>
                    <option value="">Select Instructor</option>
                    <?php while ($instructor = $instructors_result->fetch_assoc()): ?>
                        <option value="<?php echo $instructor['id']; ?>" <?php echo (isset($assignment) && $assignment['instructor_id'] == $instructor['id']) ? 'selected' : ''; ?>><?php echo $instructor['full_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col">
                <select name="entry_year" class="form-control" required>
                    <option value="">Select Entry Year</option>
                    <?php while ($entry_year = $entry_years_result->fetch_assoc()): ?>
                        <option value="<?php echo $entry_year['year']; ?>" <?php echo (isset($assignment) && $assignment['entry_year'] == $entry_year['year']) ? 'selected' : ''; ?>><?php echo $entry_year['year']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col">
                <?php if (isset($assignment)): ?>
                    <input type="hidden" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>">
                    <button type="submit" name="update" class="btn btn-success">Update Assignment</button>
                <?php else: ?>
                    <button type="submit" name="assign" class="btn btn-primary">Assign Instructor</button>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <!-- Filter Form -->
    <form method="GET" class="mb-4">
    <div class="form-row">
        <div class="col">
            <select name="filter_year" class="form-control" onchange="this.form.submit()">
                <option value="">Select Entry Year to Filter</option>
                <?php foreach ($entry_years as $year): ?>
                    <option value="<?php echo $year; ?>" <?php echo ($year == $selected_year) ? 'selected' : ''; ?>><?php echo $year; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col">
            <select name="filter_section" class="form-control" onchange="this.form.submit()">
                <option value="">Select Section to Filter</option>
                <?php
                // Reset the result pointer to fetch sections again for the dropdown
                $sections_result->data_seek(0); // Reset pointer to the start
                while ($section = $sections_result->fetch_assoc()): ?>
                    <option value="<?php echo $section['section_id']; ?>" <?php echo ($section['section_id'] == $selected_section) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($section['section_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
    </div>
</form>

    <!-- Table to display current assignments grouped by Entry Year -->
    <h2 class="text-center">Current Assignments</h2>
    <?php foreach ($assignments_by_year as $year => $assignments): ?>
        <?php if ($selected_year && $year != $selected_year) continue; ?>
        <h3><?php echo htmlspecialchars($year); ?></h3>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Section</th>
                    <th>Instructor</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($assignments)): ?>
                    <tr>
                        <td colspan="5" class="text-center">No assignments found for this year.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($assignments as $assignment): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($assignment['course_name']); ?></td>
                            <td><?php echo htmlspecialchars($assignment['section_name']); ?></td>
                            <td><?php echo htmlspecialchars($assignment['instructor_name']); ?></td>
                            <td><?php echo htmlspecialchars($assignment['created_at']); ?></td>
                            <td>
                                <a href="?edit=<?php echo $assignment['assignment_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="?delete=<?php echo $assignment['assignment_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this assignment?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endforeach; ?>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>