<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
// Database connection
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set timezone
date_default_timezone_set("Africa/Addis_Ababa");

// Fetch data from the database
$courses = $conn->query("SELECT * FROM courses")->fetch_all(MYSQLI_ASSOC);
$classrooms = $conn->query("SELECT * FROM classrooms")->fetch_all(MYSQLI_ASSOC);
$assignments = $conn->query("SELECT * FROM assignments")->fetch_all(MYSQLI_ASSOC);

// Define time slots (e.g., 8:00 AM to 5:00 PM)
$time_slots = [];
for ($hour = 8; $hour <= 17; $hour++) {
    $time_slots[] = sprintf("%02d:00", $hour) . ":00";
}

// Function to check availability for classrooms, considering all entries
function isClassroomAvailable($conn, $classroom_id, $day, $start_time, $end_time) {
    $stmt = $conn->prepare("
        SELECT COUNT(*) 
        FROM class_schedule 
        WHERE 
            classroom_id = ? 
            AND day_of_week = ? 
            AND (
                (start_time < ? AND end_time > ?) OR 
                (start_time >= ? AND start_time < ?)
            )
    ");
    $count = 0;
    $stmt->bind_param("isssss", $classroom_id, $day, $end_time, $start_time, $start_time, $end_time);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count == 0; // True if available
}

// Function to check instructor availability
function isInstructorAvailable($conn, $instructor_id, $day, $start_time, $end_time) {
    $stmt = $conn->prepare("
        SELECT COUNT(*) 
        FROM class_schedule 
        WHERE 
            instructor_id = ? 
            AND day_of_week = ? 
            AND (
                (start_time < ? AND end_time > ?) OR 
                (start_time >= ? AND start_time < ?)
            )
    ");
    $count = 0;
    $stmt->bind_param("isssss", $instructor_id, $day, $end_time, $start_time, $start_time, $end_time);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count == 0; // True if available
}

// Generate the schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Clear the existing schedule
    $conn->query("DELETE FROM class_schedule");

    foreach ($assignments as $assignment) {
        $instructor_id = $assignment['instructor_id'];
        $course_id = $assignment['course_id'];
        $section_id = $assignment['section_id'];
        $entry_year = $assignment['entry_year'];

        // Fetch course duration
        $course = array_filter($courses, fn($c) => $c['course_id'] == $course_id);
        $course = reset($course);
        $course_duration = $course['duration']; // Assuming duration is in hours

        // Shuffle days for randomization
        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
        shuffle($days);

        // Assign a day and time slot
        foreach ($days as $day) {
            foreach ($time_slots as $start_time) {
                $end_time = date("H:i:s", strtotime($start_time) + $course_duration * 3600);

                // Ensure the course does not exceed the last time slot
                if (strtotime($end_time) > strtotime("17:00:00")) {
                    continue;
                }

                // Check availability for the classroom and instructor
                foreach ($classrooms as $classroom) {
                    if (isClassroomAvailable($conn, $classroom['classroom_id'], $day, $start_time, $end_time) &&
                        isInstructorAvailable($conn, $instructor_id, $day, $start_time, $end_time)) {
                        
                        // Save schedule
                        $stmt = $conn->prepare("
                            INSERT INTO class_schedule (course_id, section_id, instructor_id, classroom_id, entry_year, day_of_week, start_time, end_time) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->bind_param("iiiiisss", $course_id, $section_id, $instructor_id, $classroom['classroom_id'], $entry_year, $day, $start_time, $end_time);
                        $stmt->execute();
                        $stmt->close();
                        break 3; // Exit all loops after scheduling
                    }
                }
            }
        }
    }
    $message = "Class schedule generated successfully.";
}
// Post schedule (copy from class_schedule to posted_schedule)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_schedule'])) {
    // Clear the posted_schedule table
    $conn->query("DELETE FROM posted_schedule");

    // Copy data from class_schedule to posted_schedule
    $copy_query = "INSERT INTO posted_schedule (course_id, section_id, instructor_id, classroom_id, entry_year, day_of_week, start_time, end_time)
                   SELECT course_id, section_id, instructor_id, classroom_id, entry_year, day_of_week, start_time, end_time
                   FROM class_schedule";
    if ($conn->query($copy_query) === TRUE) {
        $message = "Schedule posted successfully.";
    } else {
        $message = "Error posting schedule: " . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Scheduling</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f7fa;
            color: #333;
        }
        header {
            background-color: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-top: 20px;
        }
        .table {
            margin-bottom: 30px;
        }
        .btn-generate {
            margin: 20px 0;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #28a745;
            color: white;
            border: none;
            transition: background-color 0.3s;
        }
        .btn-generate:hover {
            background-color: #218838;
        }
        .message {
            margin: 20px 0;
            padding: 10px;
            background-color: #e9ecef;
            border-left: 5px solid #28a745;
        }
        .btn-post {
    border: 2px solid transparent; /* No visible border initially */
    border-radius: 25px; /* Curved corners */
    background-color: white; /* White background */
    color: black; /* Text color */
    padding: 10px 20px; /* Padding for a better look */
    transition: border-color 0.3s, background-color 0.3s, color 0.3s; /* Transition effects */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
}

.btn-post:hover {
    border-color: #333; /* Display border color on hover */
    background-color: #f8f9fa; /* Slightly darker background on hover */
    color: #007bff; /* Maintain text color */
}
    </style>
</head>
<body>

<header>
    <h1>Class Scheduling System</h1>
</header>

<div class="container">

<h2>Generate Class Schedule</h2>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <form method="POST" onsubmit="confirmScheduleGeneration(event)" class="mr-2">
            <button type="submit" name="generate_schedule" class="btn btn-generate">
                <i class="fas fa-sync-alt"></i> Generate Schedule
            </button>
        </form>

    </div>
    
    <div class="text-right">
    <form method="POST" onsubmit="return confirmPostSchedule();">
    <button type="submit" name="post_schedule" class="btn btn-post">
        <i class="fas fa-paper-plane"></i> Post Schedule
    </button>
</form>
        <br>
        <a href="manual_schedule.php" class="btn btn-secondary mx-1">
            <i class="fas fa-calendar-alt"></i> Manual Schedule
        </a>
        <a href="manual_schedule.php" class="btn btn-primary mx-1">
            <i class="fas fa-edit"></i> Edit Schedule
        </a>
    </div>
</div>
    <?php if (isset($message)): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>

    <?php
    // Reconnect to database to fetch schedules for display
    $conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");
    $schedules = $conn->query("
        SELECT cs.*, 
               s.section_name, 
               u.full_name, 
               c.room_name,
               co.course_name 
        FROM class_schedule cs
        JOIN sections s ON cs.section_id = s.section_id
        JOIN users u ON cs.instructor_id = u.id
        JOIN classrooms c ON cs.classroom_id = c.classroom_id
        JOIN courses co ON cs.course_id = co.course_id
        ORDER BY cs.entry_year, cs.day_of_week, cs.start_time
    ")->fetch_all(MYSQLI_ASSOC);
    $conn->close();

    // Group schedules by entry year
    $grouped_schedules = [];
    foreach ($schedules as $schedule) {
        $grouped_schedules[$schedule['entry_year']][] = $schedule;
    }

    foreach ($grouped_schedules as $entry_year => $schedules): ?>
        <h2>Entry Year: <?= htmlspecialchars($entry_year) ?></h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Section Name</th>
                    <th>Instructor Name</th>
                    <th>Room Name</th>
                    <th>Day</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($schedules as $schedule): ?>
                    <tr>
                        <td><?= htmlspecialchars($schedule['course_name']) ?></td>
                        <td><?= htmlspecialchars($schedule['section_name']) ?></td>
                        <td><?= htmlspecialchars($schedule['full_name']) ?></td>
                        <td><?= htmlspecialchars($schedule['room_name']) ?></td>
                        <td><?= htmlspecialchars($schedule['day_of_week']) ?></td>
                        <td><?= htmlspecialchars($schedule['start_time']) ?></td>
                        <td><?= htmlspecialchars($schedule['end_time']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endforeach; ?>
</div>
<script>
    function confirmScheduleGeneration(event) {
    const confirmation = confirm("Are you sure you want to generate New schedule? This will delete the existing schedule.");
    if (!confirmation) {
        event.preventDefault(); // Prevent form submission
    }
}
function confirmPostSchedule() {
        return confirm("Are you sure you want to post the schedule? This will overwrite any existing posted schedule.");
    }

</script>
</body>
</html>