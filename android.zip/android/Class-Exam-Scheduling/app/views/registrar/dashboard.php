<?php
session_start();

// Check if the user is logged in and is an assistant registrar
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Handle logout if the request is made
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_destroy(); // Destroy the session
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php"); // Redirect to the login page
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Assistant Registrar Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            margin-bottom: 20px;
            background-color: #007bff;
        }
        .navbar-brand {
            color: #ffffff !important;
        }
        .card {
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            border: none;
            border-radius: 15px;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        .card i {
            color: #007bff;
        }
        .logout-button {
            margin-top: 20px;
            width: 100%;
            padding: 10px;
            text-align: center;
            background-color: #dc3545;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
            border-radius: 8px;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Registrar Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <form method="POST" class="d-inline">
                            <button type="submit" name="logout" class="btn btn-danger">Logout</button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center mb-4">Assistant Registrar Dashboard</h1>
        <div class="row">
            <div class="col-md-4 mb-4">
                <a href="view_complaints.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-chat-dots fs-1"></i>
                        <h5 class="card-title">View Complaints</h5>
                        <p class="card-text">Check and manage student complaints.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="manage_department.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-building fs-1"></i>
                        <h5 class="card-title">Manage Departments</h5>
                        <p class="card-text">Create and manage academic departments.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="generate_schedule.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-calendar fs-1"></i>
                        <h5 class="card-title">Generate Class Schedule</h5>
                        <p class="card-text">Create course schedules for classes.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="manage_section.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-file-earmark-text fs-1"></i>
                        <h5 class="card-title">Manage Section</h5>
                        <p class="card-text">Organize student sections for courses.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="exam_schedule.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-calendar fs-1"></i>
                        <h5 class="card-title">Generate Exam Schedule</h5>
                        <p class="card-text">Create Exam schedules for Students.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="assign_instructor.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-person-check fs-1"></i>
                        <h5 class="card-title">Assign Instructor</h5>
                        <p class="card-text">Assign instructors to various courses.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="manage_course.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-book fs-1"></i>
                        <h5 class="card-title">Manage Course</h5>
                        <p class="card-text">Create and manage courses offered.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="manage_class_room.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-door-open fs-1"></i>
                        <h5 class="card-title">Manage Class Room</h5>
                        <p class="card-text">Oversee classroom assignments and resources.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 mb-4">
                <a href="manage_entry_year.php" class="card text-decoration-none">
                    <div class="card-body text-center">
                        <i class="bi bi-calendar-check fs-1"></i>
                        <h5 class="card-title">Manage Entry Year</h5>
                        <p class="card-text">Adjust entry year settings for students.</p>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>