<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
// Database connection
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for adding a new entry year
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $year = $_POST['year'];

    // Insert new entry year
    $stmt = $conn->prepare("INSERT INTO entry_year (year) VALUES (?)");
    $stmt->bind_param("i", $year);
    $stmt->execute();
    $stmt->close();
    $success_message = "Entry year added successfully!";
}

// Handle update logic
if (isset($_GET['edit'])) {
    $year_id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM entry_year WHERE year_id = ?");
    $stmt->bind_param("i", $year_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $entry_year = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $year_id = $_POST['year_id'];
    $year = $_POST['year'];

    // Update entry year
    $stmt = $conn->prepare("UPDATE entry_year SET year = ? WHERE year_id = ?");
    $stmt->bind_param("ii", $year, $year_id);
    $stmt->execute();
    $stmt->close();
    $success_message = "Entry year updated successfully!";
}

// Handle deletion
if (isset($_GET['delete'])) {
    $year_id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM entry_year WHERE year_id = ?");
    $stmt->bind_param("i", $year_id);
    $stmt->execute();
    $stmt->close();
    $success_message = "Entry year deleted successfully!";
}

// Fetch current entry years
$entry_years_result = $conn->query("SELECT * FROM entry_year");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Entry Years</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { 
            background-color: #f8f9fa; 
        }
        .container { 
            margin-top: 20px; 
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Manage Entry Years</h1>

    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>

    <!-- Form to add/update an entry year -->
    <form method="POST" class="mb-4">
        <div class="form-row">
            <div class="col">
                <input type="number" name="year" class="form-control" placeholder="Entry Year" required value="<?php echo isset($entry_year) ? $entry_year['year'] : ''; ?>">
                <?php if (isset($entry_year)): ?>
                    <input type="hidden" name="year_id" value="<?php echo $entry_year['year_id']; ?>">
                    <button type="submit" name="update" class="btn btn-success mt-2">Update Entry Year</button>
                <?php else: ?>
                    <button type="submit" name="add" class="btn btn-primary mt-2">Add Entry Year</button>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <!-- Table to display current entry years -->
    <h2 class="text-center">Current Entry Years</h2>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Year ID</th>
                <th>Year</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($entry_year = $entry_years_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $entry_year['year_id']; ?></td>
                <td><?php echo $entry_year['year']; ?></td>
                <td>
                    <a href="?edit=<?php echo $entry_year['year_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="?delete=<?php echo $entry_year['year_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this entry year?');">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>