<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and has the right permissions
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}

// Clear the posted_schedule table
$clear_query = "DELETE FROM posted_schedule";
if ($conn->query($clear_query) === TRUE) {
    echo "posted_schedule table cleared successfully.<br>";
} else {
    echo "Error clearing posted_schedule table: " . $conn->error . "<br>";
}

// Fetch all schedules from class_schedule
$query = "SELECT 
              course_id, 
              section_id, 
              instructor_id, 
              classroom_id, 
              entry_year, 
              day_of_week, 
              start_time, 
              end_time 
          FROM class_schedule";

$result = $conn->query($query);

if ($result) {
    // Prepare the insert statement for posted_schedule
    $insert_query = "INSERT INTO posted_schedule 
                     (course_id, section_id, instructor_id, classroom_id, entry_year, day_of_week, start_time, end_time) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($insert_query);

    // Loop through each schedule and insert into posted_schedule
    while ($row = $result->fetch_assoc()) {
        $stmt->bind_param("iiissssss", 
            $row['course_id'], 
            $row['section_id'], 
            $row['instructor_id'], 
            $row['classroom_id'], 
            $row['entry_year'], 
            $row['day_of_week'], 
            $row['start_time'], 
            $row['end_time']
        );
        
        if (!$stmt->execute()) {
            echo "Error inserting schedule: " . $stmt->error . "<br>";
        }
    }

    echo "All schedules copied to posted_schedule successfully!";
} else {
    echo "Error fetching schedules: " . $conn->error;
}

$stmt->close();
$conn->close();
?>