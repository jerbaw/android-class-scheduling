<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'assistant_registrar') {
    // Redirect to login page if not logged in or not an admin
    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
    exit();
}
// Database connection
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for adding a new section
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_section'])) {
    $section_name = $_POST['section_name'];

    $stmt = $conn->prepare("INSERT INTO sections (section_name, created_at) VALUES (?, NOW())");
    $stmt->bind_param("s", $section_name);
    $stmt->execute();
    $stmt->close();
}

// Handle deletion of a section
if (isset($_GET['delete'])) {
    $section_id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM sections WHERE section_id = ?");
    $stmt->bind_param("i", $section_id);
    $stmt->execute();
    $stmt->close();
}

// Fetch current sections
$sections_result = $conn->query("SELECT * FROM sections");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sections</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { 
            background-color: #f8f9fa; 
        }
        .container { 
            margin-top: 20px; 
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Manage Sections</h1>

    <!-- Form to add a new section -->
    <form method="POST" class="mb-4">
        <div class="form-row">
            <div class="col">
                <input type="text" name="section_name" class="form-control" placeholder="Section Name" required>
            </div>
            <div class="col">
                <button type="submit" name="add_section" class="btn btn-primary">Add Section</button>
            </div>
        </div>
    </form>

    <!-- Table to display current sections -->
    <h2 class="text-center">Current Sections</h2>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Section ID</th>
                <th>Section Name</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($section = $sections_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $section['section_id']; ?></td>
                <td><?php echo $section['section_name']; ?></td>
                <td><?php echo $section['created_at']; ?></td>
                <td>
                    <a href="?delete=<?php echo $section['section_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this section?');">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>