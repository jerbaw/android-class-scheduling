<?php
session_start();

// Database connection
try {
    $pdo = new PDO("mysql:host=localhost;dbname=class_and_exam_scheduling", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $error = '';

    try {
        // Prepare the query to find the user
        $query = "SELECT * FROM users WHERE username = :username";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verify password and check user status
        if ($user && password_verify($password, $user['password']) && $user['status'] == 'active') {
            // Correct password and active status, create session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['department_id'] = $user['department_id'];

            switch ($user['role']) {
                case 'student':
                    header('Location: /Class-Exam-Scheduling/app/views/student/dashboard.php');
                    break;
                case 'instructor':
                    header('Location: /Class-Exam-Scheduling/app/views/instructor/dashboard.php');
                    break;
                case 'dept_head':
                    header('Location: /Class-Exam-Scheduling/app/views/dept_head/dashboard.php');
                    break;
                case 'assistant_registrar':
                    header('Location: /Class-Exam-Scheduling/app/views/registrar/dashboard.php');
                    break;
                case 'admin':
                    header('Location: /Class-Exam-Scheduling/app/views/admin/sidebar.php');
                    break;
                default: 
                    echo "Invalid role.";
                    break;
                }    
            exit();
        } else {
            $error = "Invalid username or password, or your account is inactive.";
        }
    } catch (PDOException $e) {
        die("Database query failed: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
        }
        .login-container h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
            <p class="text-center mt-3"><a href="password_recovery.php">Forgot Password?</a></p>
        </form>
    </div>
</body>
</html>
