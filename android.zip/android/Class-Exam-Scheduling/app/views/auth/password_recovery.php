<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");
require_once 'vendor/autoload.php'; // Corrected path and added autoload

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Check for POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get email from POST request
    $email = $_POST['email'];

    // Validate if the email is provided
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'A valid email is required.';
        exit;
    }

    // Check if the email exists in the users table
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            // Generate a random recovery token
            $token = bin2hex(random_bytes(16)); // 32 characters long token

            // Set the expiration time (24 hours from now)
            $expiry = date('Y-m-d H:i:s', strtotime('+1 day'));

            // Insert the recovery request into the database
            $stmt = $conn->prepare("INSERT INTO password_recovery_requests (user_id, recovery_token, expiration_time) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $user['id'], $token, $expiry); // Changed from user['user_id'] to user['id']
            $stmt->execute();

            // Send the recovery email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->SMTPAuth = true;
                $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
                $mail->Username = "eyuelalemnew227@gmail.com";
                $mail->Password = "zesr rdgp rhxo yqdv";

                // Recipients
                $mail->setFrom('no-reply@yourdomain.com', 'Password Recovery');
                $mail->addAddress($email); // Add the user's email address

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Request';
                $mail->Body = 'To reset your password, click the following link: ' .
                              'http://localhost/Class-Exam-Scheduling/app/views/auth/reset_password.php?token=' . $token;

                // Send email
                $mail->send();
                echo 'Password reset link has been sent to your email address.';
            } catch (Exception $e) {
                echo 'Failed to send reset email. Please try again. Error: ' . $mail->ErrorInfo;
            }
        } else {
            echo 'No account found with that email address.';
        }
    } catch (mysqli_sql_exception $e) {
        echo "An error occurred: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Recovery</title>
    <link rel="stylesheet" href="/public/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Password Recovery</h2>
        <form action="password_recovery.php" method="POST">
            <div class="form-group">
                <label for="email">Email address:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>