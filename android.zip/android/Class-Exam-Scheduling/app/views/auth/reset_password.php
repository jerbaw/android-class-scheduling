<?php
session_start();
$conn = new mysqli("localhost", "root", "", "class_and_exam_scheduling");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Check if the token exists and is not expired
    try {
        $stmt = $conn->prepare("SELECT * FROM password_recovery_requests WHERE recovery_token = ? AND expiration_time > NOW() AND is_used = 0");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        $request = $result->fetch_assoc();

        if ($request) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Handle the password reset logic
                $new_password = $_POST['new_password'];

                // Validate password strength
                if (strlen($new_password) < 8) {
                    echo 'Password must be at least 8 characters long.';
                } elseif (!preg_match('/[A-Za-z]/', $new_password) || !preg_match('/[0-9]/', $new_password)) {
                    echo 'Password must contain both letters and numbers.';
                } else {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                    // Update the user's password
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->bind_param("si", $hashed_password, $request['user_id']);
                    $stmt->execute();

                    // Mark the token as used
                    $stmt = $conn->prepare("UPDATE password_recovery_requests SET is_used = 1 WHERE request_id = ?");
                    $stmt->bind_param("i", $request['request_id']);
                    $stmt->execute();

                    // Redirect to the login page after a successful password reset
                    header("Location: /Class-Exam-Scheduling/app/views/auth/login.php");
                    exit();
                }
            }
        } else {
            echo 'Invalid or expired token.';
        }
    } catch (Exception $e) {
        echo "An error occurred: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="/public/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Reset Your Password</h2>
        <form action="reset_password.php?token=<?php echo htmlspecialchars($_GET['token']); ?>" method="POST">
            <div class="form-group">
                <label for="new_password">New Password:</label>
                <input type="password" class="form-control" id="new_password" name="new_password" required>
            </div>
            <button type="submit" class="btn btn-primary">Reset Password</button>
        </form>
    </div>
</body>
</html>